import crypto from 'node:crypto'
import config from '../config.js'
import { calc, rand, pick, numOf } from '../lib/utils.js'

export const category = 'Utilidades'

const MORSE = {
  a: '.-', b: '-...', c: '-.-.', d: '-..', e: '.', f: '..-.', g: '--.', h: '....', i: '..', j: '.---',
  k: '-.-', l: '.-..', m: '--', n: '-.', o: '---', p: '.--.', q: '--.-', r: '.-.', s: '...', t: '-',
  u: '..-', v: '...-', w: '.--', x: '-..-', y: '-.--', z: '--..',
  0: '-----', 1: '.----', 2: '..---', 3: '...--', 4: '....-', 5: '.....', 6: '-....', 7: '--...', 8: '---..', 9: '----.',
}
const UNMORSE = Object.fromEntries(Object.entries(MORSE).map(([k, v]) => [v, k]))
const input = (c) => c.text || c.quotedText || ''
const need = (c, usage) => c.reply(`Uso: ${c.prefix}${c.command} ${usage}`)

const hashCmd = (name, algo) => ({
  name, desc: `Hash ${algo.toUpperCase()} de un texto`, usage: '<texto>',
  async run(c) {
    const s = input(c)
    if (!s) return need(c, '<texto>')
    c.reply(`🔐 *${algo.toUpperCase()}*\n${crypto.createHash(algo).update(s).digest('hex')}`)
  },
})

const shift = (s, n) =>
  [...s].map((ch) => {
    const code = ch.charCodeAt(0)
    if (code >= 65 && code <= 90) return String.fromCharCode(((code - 65 + n) % 26 + 26) % 26 + 65)
    if (code >= 97 && code <= 122) return String.fromCharCode(((code - 97 + n) % 26 + 26) % 26 + 97)
    return ch
  }).join('')

export default [
  {
    name: 'calc', aliases: ['calcular', 'calculadora'], desc: 'Calculadora (+ - * / % ^ sqrt sin cos pi...)', usage: '<operación>',
    async run(c) {
      if (!c.text) return need(c, '2*(3+4)^2')
      try {
        const r = calc(c.text)
        if (!Number.isFinite(r)) return c.reply('❌ El resultado no es un número válido.')
        c.reply(`🧮 ${c.text} = *${+r.toFixed(10)}*`)
      } catch (e) { c.reply(`❌ ${e.message}`) }
    },
  },
  {
    name: 'qr', aliases: ['crearqr'], desc: 'Genera un código QR', usage: '<texto o enlace>',
    async run(c) {
      const s = input(c)
      if (!s) return need(c, '<texto>')
      const url = `https://api.qrserver.com/v1/create-qr-code/?size=500x500&margin=10&data=${encodeURIComponent(s)}`
      await c.send({ image: { url }, caption: '✅ Tu código QR' })
    },
  },
  {
    name: 'password', aliases: ['contrasena', 'pass'], desc: 'Genera una contraseña segura', usage: '[longitud]',
    async run(c) {
      const len = Math.min(Math.max(parseInt(c.args[0]) || 16, 6), 64)
      const chars = 'abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#$%^&*-_+='
      let out = ''
      for (let i = 0; i < len; i++) out += chars[crypto.randomInt(chars.length)]
      c.reply(`🔑 *Contraseña (${len})*\n\`${out}\``)
    },
  },
  {
    name: 'b64enc', aliases: ['base64'], desc: 'Codifica texto a Base64', usage: '<texto>',
    async run(c) { const s = input(c); if (!s) return need(c, '<texto>'); c.reply(Buffer.from(s).toString('base64')) },
  },
  {
    name: 'b64dec', aliases: ['unbase64'], desc: 'Decodifica Base64 a texto', usage: '<base64>',
    async run(c) {
      const s = input(c)
      if (!s) return need(c, '<base64>')
      c.reply(Buffer.from(s, 'base64').toString('utf8'))
    },
  },
  {
    name: 'urlenc', aliases: ['urlencode'], desc: 'Codifica texto para URL', usage: '<texto>',
    async run(c) { const s = input(c); if (!s) return need(c, '<texto>'); c.reply(encodeURIComponent(s)) },
  },
  {
    name: 'urldec', aliases: ['urldecode'], desc: 'Decodifica texto de URL', usage: '<texto>',
    async run(c) {
      const s = input(c)
      if (!s) return need(c, '<texto>')
      try { c.reply(decodeURIComponent(s)) } catch { c.reply('❌ Texto inválido.') }
    },
  },
  hashCmd('md5', 'md5'),
  hashCmd('sha1', 'sha1'),
  hashCmd('sha256', 'sha256'),
  {
    name: 'uuid', aliases: ['guid'], desc: 'Genera un UUID v4',
    async run(c) { c.reply(`🆔 ${crypto.randomUUID()}`) },
  },
  {
    name: 'fecha', aliases: ['date', 'hoy'], desc: 'Fecha actual', usage: '[zona horaria]',
    async run(c) {
      const tz = c.args[0] || config.timezone
      try {
        c.reply('📅 ' + new Date().toLocaleDateString('es-ES', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', timeZone: tz }) + `\n🌍 ${tz}`)
      } catch { c.reply('❌ Zona horaria inválida. Ejemplo: America/Bogota') }
    },
  },
  {
    name: 'hora', aliases: ['time'], desc: 'Hora actual', usage: '[zona horaria]',
    async run(c) {
      const tz = c.args[0] || config.timezone
      try {
        c.reply('🕒 ' + new Date().toLocaleTimeString('es-ES', { timeZone: tz, hour12: false }) + `\n🌍 ${tz}`)
      } catch { c.reply('❌ Zona horaria inválida. Ejemplo: Europe/Madrid') }
    },
  },
  {
    name: 'unix', aliases: ['timestamp'], desc: 'Timestamp UNIX ↔ fecha', usage: '[timestamp | fecha]',
    async run(c) {
      if (!c.text) return c.reply(`⏱️ Ahora: *${Math.floor(Date.now() / 1000)}*`)
      if (/^\d{9,13}$/.test(c.text)) {
        const n = Number(c.text)
        const d = new Date(c.text.length > 10 ? n : n * 1000)
        return c.reply(`📆 ${d.toISOString()}`)
      }
      const d = new Date(c.text)
      if (isNaN(d)) return c.reply('❌ Fecha inválida. Ejemplo: 2026-12-25 10:00')
      c.reply(`⏱️ *${Math.floor(d.getTime() / 1000)}*`)
    },
  },
  {
    name: 'aleatorio', aliases: ['random', 'rnd'], desc: 'Número aleatorio en un rango', usage: '[min] [max]',
    async run(c) {
      let [a, b] = c.args.map(Number)
      if (isNaN(a)) { a = 1; b = 100 } else if (isNaN(b)) { b = a; a = 1 }
      if (a > b) [a, b] = [b, a]
      c.reply(`🎲 Entre ${a} y ${b}: *${rand(a, b)}*`)
    },
  },
  {
    name: 'elegir', aliases: ['choose', 'decide'], desc: 'Elige una opción al azar', usage: 'a|b|c',
    async run(c) {
      const opts = c.text.split(/\||,/).map((s) => s.trim()).filter(Boolean)
      if (opts.length < 2) return need(c, 'pizza|tacos|sushi')
      c.reply(`🤔 Elijo: *${pick(opts)}*`)
    },
  },
  {
    name: 'recordar', aliases: ['remind', 'recordatorio'], desc: 'Te recuerda algo en X tiempo (máx 24h)', usage: '10m <mensaje>',
    async run(c) {
      const m = /^(\d+)\s*(s|m|h)$/i.exec(c.args[0] || '')
      const msg = c.args.slice(1).join(' ')
      if (!m || !msg) return need(c, '10m sacar la basura   (s, m o h)')
      const ms = Number(m[1]) * { s: 1000, m: 60000, h: 3600000 }[m[2].toLowerCase()]
      if (ms < 1000 || ms > 86_400_000) return c.reply('❌ Elige entre 1 segundo y 24 horas.')
      setTimeout(() => {
        c.sock.sendMessage(c.from, { text: `⏰ @${numOf(c.sender)} recordatorio: *${msg}*`, mentions: [c.sender] }).catch(() => {})
      }, ms)
      c.reply(`✅ Te lo recordaré en ${m[1]}${m[2]}. (Si el bot se reinicia, se pierde)`)
    },
  },
  {
    name: 'morse', desc: 'Texto a código morse', usage: '<texto>',
    async run(c) {
      const s = input(c).toLowerCase()
      if (!s) return need(c, '<texto>')
      c.reply([...s].map((ch) => (ch === ' ' ? '/' : MORSE[ch] || '')).filter(Boolean).join(' '))
    },
  },
  {
    name: 'demorse', desc: 'Código morse a texto', usage: '<morse>',
    async run(c) {
      const s = input(c)
      if (!s) return need(c, '.... --- .-.. .-')
      c.reply(s.trim().split(/\s*\/\s*/).map((w) => w.split(/\s+/).map((x) => UNMORSE[x] || '?').join('')).join(' '))
    },
  },
  {
    name: 'caesar', aliases: ['cesar'], desc: 'Cifrado César (negativo para descifrar)', usage: '<desplazamiento> <texto>',
    async run(c) {
      const n = parseInt(c.args[0])
      const s = c.args.slice(1).join(' ') || c.quotedText
      if (isNaN(n) || !s) return need(c, '3 hola mundo')
      c.reply(shift(s, n))
    },
  },
  {
    name: 'rot13', desc: 'Cifrado ROT13', usage: '<texto>',
    async run(c) { const s = input(c); if (!s) return need(c, '<texto>'); c.reply(shift(s, 13)) },
  },
  {
    name: 'binario', aliases: ['tobinary'], desc: 'Texto a binario', usage: '<texto>',
    async run(c) {
      const s = input(c)
      if (!s) return need(c, '<texto>')
      c.reply([...Buffer.from(s)].map((b) => b.toString(2).padStart(8, '0')).join(' '))
    },
  },
  {
    name: 'debinario', aliases: ['frombinary'], desc: 'Binario a texto', usage: '<binario>',
    async run(c) {
      const parts = input(c).trim().split(/\s+/)
      if (!parts[0] || parts.some((p) => !/^[01]{8}$/.test(p))) return c.reply('❌ Usa bytes de 8 bits separados por espacio.')
      c.reply(Buffer.from(parts.map((p) => parseInt(p, 2))).toString('utf8'))
    },
  },
  {
    name: 'hexa', aliases: ['tohex'], desc: 'Texto a hexadecimal', usage: '<texto>',
    async run(c) { const s = input(c); if (!s) return need(c, '<texto>'); c.reply(Buffer.from(s).toString('hex')) },
  },
  {
    name: 'dehexa', aliases: ['fromhex'], desc: 'Hexadecimal a texto', usage: '<hex>',
    async run(c) {
      const s = input(c).replace(/\s/g, '')
      if (!/^([0-9a-f]{2})+$/i.test(s)) return c.reply('❌ Hexadecimal inválido.')
      c.reply(Buffer.from(s, 'hex').toString('utf8'))
    },
  },
  {
    name: 'color', aliases: ['colour'], desc: 'Convierte un color HEX a RGB y HSL', usage: '#ff8800',
    async run(c) {
      const m = /^#?([0-9a-f]{6})$/i.exec(c.args[0] || '')
      if (!m) return need(c, '#ff8800')
      const n = parseInt(m[1], 16)
      const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255
      const mx = Math.max(r, g, b) / 255, mn = Math.min(r, g, b) / 255, l = (mx + mn) / 2
      const d = mx - mn
      let h = 0, s = 0
      if (d) {
        s = d / (1 - Math.abs(2 * l - 1))
        const rr = r / 255, gg = g / 255, bb = b / 255
        if (mx === rr) h = ((gg - bb) / d) % 6
        else if (mx === gg) h = (bb - rr) / d + 2
        else h = (rr - gg) / d + 4
        h = (h * 60 + 360) % 360
      }
      c.reply(`🎨 *#${m[1].toUpperCase()}*\nRGB: ${r}, ${g}, ${b}\nHSL: ${Math.round(h)}°, ${Math.round(s * 100)}%, ${Math.round(l * 100)}%`)
    },
  },
  {
    name: 'edad', aliases: ['age', 'cumple'], desc: 'Calcula tu edad y días para tu cumpleaños', usage: 'AAAA-MM-DD',
    async run(c) {
      const d = new Date(c.args[0] + 'T00:00:00')
      const now = new Date()
      if (!c.args[0] || isNaN(d) || d > now) return need(c, '1995-03-21')
      let years = now.getFullYear() - d.getFullYear()
      let next = new Date(now.getFullYear(), d.getMonth(), d.getDate())
      if (next < new Date(now.getFullYear(), now.getMonth(), now.getDate())) { next = new Date(now.getFullYear() + 1, d.getMonth(), d.getDate()) }
      if (new Date(now.getFullYear(), d.getMonth(), d.getDate()) > now) years--
      const days = Math.ceil((next - now) / 86_400_000)
      c.reply(`🎂 Tienes *${years} años*.\nFaltan *${days} días* para tu próximo cumpleaños.`)
    },
  },
]
