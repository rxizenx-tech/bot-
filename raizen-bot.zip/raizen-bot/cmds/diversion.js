import { pick, rand, numOf, hash100, norm } from '../lib/utils.js'

export const category = 'Diversión'

// Estado de juegos en memoria (se pierde al reiniciar)
const quiz = new Map() // chat -> { answer, type, reward }
const guess = new Map() // chat:user -> { n, tries }
const hang = new Map() // chat -> { word, found, wrong }

const CHISTES = [
  '¿Qué le dice un cero a otro cero? — No valemos nada.',
  '¿Por qué los pájaros vuelan hacia el sur? — Porque caminando tardarían mucho.',
  '¿Qué hace una abeja en el gimnasio? — ¡Zum-ba!',
  '¿Cómo se despiden los químicos? — Ácido un placer.',
  '¿Qué le dice una iguana a su hermana gemela? — Somos iguanitas.',
  '¿Por qué el libro de matemáticas estaba triste? — Porque tenía muchos problemas.',
  '¿Qué le dice un techo a otro techo? — Techo de menos.',
  '¿Cuál es el colmo de un electricista? — Que su esposa se llame Luz y no lo ilumine.',
  '¿Qué le dice el número 3 al número 30? — Para ser como yo, tienes que ser sincero.',
  '¿Por qué el programador se quedó sin pareja? — Porque no tenía un buen "commit"ment.',
  '¿Qué le dice una taza a otra? — ¿Qué te cuentas, "tazita"?',
  'Doctor, doctor, me siento invisible. — ¿Quién dijo eso? — Nadie...',
]
const FRASES = [
  'El éxito es la suma de pequeños esfuerzos repetidos día tras día.',
  'No cuentes los días, haz que los días cuenten.',
  'Cuando una puerta se cierra, otra se abre.',
  'La disciplina es el puente entre las metas y los logros.',
  'Nunca es tarde para ser lo que podrías haber sido.',
  'Lo que haces hoy puede mejorar todos tus mañanas.',
  'Cae siete veces, levántate ocho.',
  'La mejor forma de predecir el futuro es crearlo.',
  'Sé el cambio que quieres ver en el mundo.',
  'Hazlo con miedo, pero hazlo.',
]
const PIROPOS = [
  'Si fueras un videojuego, serías el que nunca quiero terminar. 🎮',
  'Eres como el Wi-Fi: cuando no estás, me siento desconectado. 📶',
  'Si la belleza fuera un delito, estarías cumpliendo cadena perpetua. 😏',
  'No sé tu nombre, pero ya te tengo en mi lista de favoritos. ⭐',
  'Eres la razón por la que sonrío viendo el celular. 📱',
  '¿Eres café? Porque contigo se me quita el sueño. ☕',
  'Tienes más encanto que un código sin errores. 💻',
  'Si fueras una canción, estarías en mi playlist en repetición. 🎶',
]
const RETOS = [
  'Envía un audio cantando tu canción favorita.',
  'Cambia tu foto de perfil por una de tu infancia por 24 horas.',
  'Escribe tu próximo mensaje usando solo emojis.',
  'Haz 15 sentadillas y cuenta cómo te fue.',
  'Dile algo bonito a la última persona que te escribió.',
  'Habla con acento extranjero durante los próximos 5 mensajes.',
  'Cuenta un dato curioso que casi nadie sepa de ti.',
  'Escribe un poema de 4 líneas sobre el último objeto que veas.',
]
const VERDADES = [
  '¿Cuál ha sido tu mayor vergüenza?',
  '¿Qué es lo más raro que has buscado en internet?',
  '¿Cuál es tu mayor miedo irracional?',
  '¿Qué app usas más y no admites en público?',
  '¿Cuál fue tu primer trabajo o ingreso?',
  '¿Qué hábito tuyo te gustaría cambiar?',
  '¿A quién del grupo le escribirías más seguido si tuvieras tiempo?',
  '¿Cuál es la mentira más grande que has dicho sin que te descubrieran?',
]
const BOLA8 = [
  'Sí, definitivamente.', 'Todo apunta a que sí.', 'Sin duda alguna.', 'Puedes confiar en ello.',
  'Es muy probable.', 'Las señales dicen que sí.', 'Pregunta de nuevo más tarde.', 'Mejor no decírtelo ahora.',
  'No puedo predecirlo ahora.', 'Concéntrate y vuelve a preguntar.', 'No cuentes con ello.',
  'Mi respuesta es no.', 'Mis fuentes dicen que no.', 'Parece que no.', 'Muy dudoso.',
]
const DATOS = [
  'Los pulpos tienen tres corazones y sangre azul. 🐙',
  'Las abejas pueden reconocer rostros humanos. 🐝',
  'Un día en Venus dura más que un año venusiano. 🪐',
  'La miel nunca se echa a perder: se han hallado frascos comestibles de miles de años. 🍯',
  'Los koalas tienen huellas dactilares casi idénticas a las humanas. 🐨',
  'El corazón de una ballena azul es del tamaño de un auto pequeño. 🐋',
  'Las bananas son ligeramente radiactivas por su contenido de potasio. 🍌',
  'Hay más estrellas en el universo que granos de arena en la Tierra. ✨',
  'Los flamencos nacen con plumas grises; el rosa viene de su dieta. 🦩',
  'El primer "bug" informático fue una polilla real atrapada en un computador. 🪲',
]
const ADIVINANZAS = [
  ['Blanca por dentro, verde por fuera. Si quieres que te lo diga, espera.', 'pera'],
  ['Tengo agujas y no sé coser, tengo números y no sé leer.', 'reloj'],
  ['Vuelo sin alas, silbo sin boca, azoto sin manos y nadie me toca.', 'viento'],
  ['Cuanto más lavo, más sucia está. ¿Qué es?', 'agua'],
  ['Oro parece, plata no es. El que no lo adivine bien tonto es.', 'platano'],
  ['Redondo, redondo, sin tapa ni fondo.', 'anillo'],
  ['Tiene dientes y no come, tiene cabeza y no es hombre.', 'ajo'],
  ['Mientras más grande, menos se ve.', 'oscuridad'],
]
const TRIVIA = [
  ['¿Cuál es el planeta más grande del sistema solar?', ['Marte', 'Júpiter', 'Saturno'], 'b'],
  ['¿Cuántos continentes hay?', ['5', '6', '7'], 'c'],
  ['¿Capital de Japón?', ['Tokio', 'Kioto', 'Osaka'], 'a'],
  ['¿Quién pintó la Mona Lisa?', ['Miguel Ángel', 'Da Vinci', 'Picasso'], 'b'],
  ['¿Cuál es el océano más grande?', ['Atlántico', 'Índico', 'Pacífico'], 'c'],
  ['¿Cuántos lados tiene un hexágono?', ['6', '8', '5'], 'a'],
  ['¿Qué gas necesitan las plantas para la fotosíntesis?', ['Oxígeno', 'CO₂', 'Nitrógeno'], 'b'],
  ['¿En qué año llegó el ser humano a la Luna?', ['1965', '1969', '1972'], 'b'],
  ['¿Cuál es el río más largo de América del Sur?', ['Amazonas', 'Orinoco', 'Paraná'], 'a'],
  ['¿Cuál es el metal líquido a temperatura ambiente?', ['Plomo', 'Mercurio', 'Aluminio'], 'b'],
]
const PREFIERES = [
  ['Poder volar', 'Ser invisible'], ['Vivir sin música', 'Vivir sin películas'],
  ['Hablar todos los idiomas', 'Hablar con animales'], ['Nunca más dormir', 'Nunca más comer'],
  ['Viajar al pasado', 'Viajar al futuro'], ['Vivir en la playa', 'Vivir en la montaña'],
  ['Tener mucho dinero', 'Tener mucho tiempo libre'], ['Perder tu celular', 'Perder tu billetera'],
]
const ROASTS = [
  'tiene tanta suerte que si lo atropella un tren, el tren llega tarde.',
  'es tan lento que el "cargando..." le gana en velocidad.',
  'tiene más pestañas abiertas que amigos reales.',
  'es la prueba de que el Wi-Fi también se puede desconectar de la realidad.',
  'dice "ya salgo" y todavía ni se ha bañado.',
  'tiene un sentido de la orientación comparable al de un GPS sin batería.',
]
const SIGNOS = ['aries', 'tauro', 'geminis', 'cancer', 'leo', 'virgo', 'libra', 'escorpio', 'sagitario', 'capricornio', 'acuario', 'piscis']
const HORO = [
  'Hoy es buen día para empezar eso que has pospuesto.', 'Una conversación inesperada te dará buenas ideas.',
  'Cuida tus gastos: tentaciones a la vista.', 'La paciencia te dará la victoria hoy.',
  'Alguien cercano necesita tu apoyo; escúchalo.', 'La suerte te sonríe en lo que hagas con constancia.',
  'Evita discusiones innecesarias; ahorra energía.', 'Una buena noticia llegará antes de que termine el día.',
]
const WORDS = ['programacion', 'whatsapp', 'computadora', 'elefante', 'guitarra', 'mariposa', 'aventura', 'chocolate', 'telefono', 'universo', 'dinosaurio', 'montana']

const pctCmd = (name, aliases, desc, icon, label) => ({
  name, aliases, desc, usage: '[@usuario]',
  async run(c) {
    const t = c.getTarget() || c.sender
    const p = hash100(`${name}:${t}:${new Date().toDateString()}`)
    c.reply(`${icon} @${numOf(t)} tiene *${p}%* de ${label} hoy.`, [t])
  },
})

const memberPick = (c, n = 1) => {
  const pool = c.isGroup ? c.participants.filter((j) => j !== c.botJid) : [c.sender]
  return [...pool].sort(() => Math.random() - 0.5).slice(0, n)
}

export default [
  {
    name: 'bola8', aliases: ['8ball', 'bola'], desc: 'Pregúntale a la bola mágica', usage: '<pregunta>',
    async run(c) {
      if (!c.text) return c.reply(`Uso: ${c.prefix}bola8 ¿Seré millonario?`)
      c.reply(`🎱 *${c.text}*\n\n${pick(BOLA8)}`)
    },
  },
  { name: 'chiste', aliases: ['joke'], desc: 'Un chiste aleatorio', async run(c) { c.reply(`😂 ${pick(CHISTES)}`) } },
  { name: 'frase', aliases: ['quote', 'motivacion'], desc: 'Frase motivadora', async run(c) { c.reply(`✨ _${pick(FRASES)}_`) } },
  {
    name: 'piropo', aliases: ['flirt'], desc: 'Un piropo (a alguien si lo mencionas)', usage: '[@usuario]',
    async run(c) {
      const t = c.getTarget()
      c.reply(`${t ? '@' + numOf(t) + ' ' : ''}${pick(PIROPOS)}`, t ? [t] : [])
    },
  },
  { name: 'reto', aliases: ['dare'], desc: 'Un reto para cumplir', async run(c) { c.reply(`🔥 *RETO*\n${pick(RETOS)}`) } },
  { name: 'verdad', aliases: ['truth'], desc: 'Una pregunta de verdad', async run(c) { c.reply(`🫣 *VERDAD*\n${pick(VERDADES)}`) } },
  {
    name: 'ppt', aliases: ['rps'], desc: 'Piedra, papel o tijera', usage: 'piedra|papel|tijera',
    async run(c) {
      const opts = ['piedra', 'papel', 'tijera']
      const icons = { piedra: '🪨', papel: '📄', tijera: '✂️' }
      const me = norm(c.args[0] || '')
      if (!opts.includes(me)) return c.reply(`Uso: ${c.prefix}ppt piedra|papel|tijera`)
      const bot = pick(opts)
      const win = { piedra: 'tijera', papel: 'piedra', tijera: 'papel' }
      const res = me === bot ? '🤝 ¡Empate!' : win[me] === bot ? '🏆 ¡Ganaste!' : '😈 ¡Gané yo!'
      c.reply(`${icons[me]} vs ${icons[bot]}\n\n${res}`)
    },
  },
  {
    name: 'dado', aliases: ['dice'], desc: 'Lanza un dado', usage: '[caras]',
    async run(c) {
      const n = Math.min(Math.max(parseInt(c.args[0]) || 6, 2), 1000)
      c.reply(`🎲 Dado de ${n} caras: *${rand(1, n)}*`)
    },
  },
  { name: 'moneda', aliases: ['coin', 'flip2'], desc: 'Cara o cruz', async run(c) { c.reply(`🪙 Salió: *${pick(['CARA', 'CRUZ'])}*`) } },
  {
    name: 'ruleta', aliases: ['roulette'], desc: 'Gira la ruleta (0-36)', usage: '[rojo|negro]',
    async run(c) {
      const n = rand(0, 36)
      const red = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]
      const color = n === 0 ? 'verde' : red.includes(n) ? 'rojo' : 'negro'
      const bet = norm(c.args[0] || '')
      const extra = ['rojo', 'negro'].includes(bet) ? (bet === color ? '\n🏆 ¡Acertaste el color!' : '\n💥 Fallaste el color.') : ''
      c.reply(`🎡 La bola cae en *${n}* (${color})${extra}`)
    },
  },
  {
    name: 'slot', aliases: ['tragamonedas'], desc: 'Máquina tragamonedas',
    async run(c) {
      const s = ['🍒', '🍋', '🍇', '🔔', '⭐', '💎']
      const r = [pick(s), pick(s), pick(s)]
      const res = r[0] === r[1] && r[1] === r[2] ? '🎉 ¡JACKPOT!' : r[0] === r[1] || r[1] === r[2] || r[0] === r[2] ? '👍 ¡Casi! Par.' : '😢 Perdiste.'
      c.reply(`🎰 | ${r.join(' | ')} |\n\n${res}`)
    },
  },
  {
    name: 'adivina', aliases: ['guess'], desc: 'Adivina el número del 1 al 100 (7 intentos)', usage: '[número]',
    async run(c) {
      const key = c.from + ':' + c.sender
      const n = parseInt(c.args[0])
      const g = guess.get(key)
      if (isNaN(n) || !g) {
        guess.set(key, { n: rand(1, 100), tries: 0 })
        return c.reply(`🔢 Pensé un número del 1 al 100. Tienes 7 intentos.\nUsa ${c.prefix}adivina <número>`)
      }
      g.tries++
      if (n === g.n) {
        guess.delete(key)
        c.user.coins += 100
        return c.reply(`🎉 ¡Correcto! Era *${g.n}* (${g.tries} intentos). Ganaste 100 monedas 🪙`)
      }
      if (g.tries >= 7) { guess.delete(key); return c.reply(`💀 Se acabaron los intentos. Era *${g.n}*.`) }
      c.reply(`${n < g.n ? '⬆️ Más alto' : '⬇️ Más bajo'}. Intentos: ${g.tries}/7`)
    },
  },
  {
    name: 'ship', aliases: ['pareja2'], desc: 'Compatibilidad entre dos personas', usage: '@a @b',
    async run(c) {
      const [a, b] = c.mentions.length >= 2 ? c.mentions : [c.sender, c.mentions[0] || c.quotedSender || memberPick(c)[0]]
      const p = hash100([a, b].sort().join('+'))
      const bar = '█'.repeat(Math.round(p / 10)).padEnd(10, '░')
      c.reply(`💘 @${numOf(a)} + @${numOf(b)}\n\n[${bar}] *${p}%*\n${p > 80 ? '¡Son almas gemelas! 💞' : p > 50 ? 'Hay química 🔥' : p > 25 ? 'Podría funcionar 🤔' : 'Mejor amigos 😅'}`, [a, b])
    },
  },
  pctCmd('carisma', ['charm'], 'Tu nivel de carisma hoy', '😎', 'carisma'),
  pctCmd('iq', ['inteligencia'], 'Tu coeficiente "intelectual" (de broma)', '🧠', 'inteligencia'),
  {
    name: 'cuanto', aliases: ['rate', 'porcentajede'], desc: 'Qué tanto eres de algo (de broma)', usage: '<algo>',
    async run(c) {
      if (!c.text) return c.reply(`Uso: ${c.prefix}cuanto <algo>   (ej: ${c.prefix}cuanto friki)`)
      const t = c.getTarget() || c.sender
      c.reply(`📊 @${numOf(t)} es *${rand(0, 100)}%* ${c.text.replace(/@\d+/g, '').trim()}`, [t])
    },
  },
  {
    name: 'horoscopo', aliases: ['horoscope', 'signo'], desc: 'Predicción del día para tu signo', usage: '<signo>',
    async run(c) {
      const s = norm(c.args[0] || '')
      if (!SIGNOS.includes(s)) return c.reply(`Uso: ${c.prefix}horoscopo <signo>\nSignos: ${SIGNOS.join(', ')}`)
      const h = hash100(s + new Date().toDateString())
      c.reply(`🔮 *${s.toUpperCase()}*\n\n${HORO[h % HORO.length]}\n\n🍀 Número de la suerte: ${h % 50 + 1}`)
    },
  },
  {
    name: 'suerte', aliases: ['luck'], desc: 'Tu suerte del día',
    async run(c) {
      const h = hash100(c.sender + new Date().toDateString())
      const colors = ['rojo', 'azul', 'verde', 'amarillo', 'morado', 'naranja', 'blanco', 'negro']
      c.reply(`🍀 *Tu suerte hoy*\n\nNivel: ${h}%\nNúmero: ${h % 99 + 1}\nColor: ${colors[h % colors.length]}`)
    },
  },
  {
    name: 'roast', aliases: ['quemar'], desc: 'Una broma ligera sobre alguien', usage: '@usuario',
    async run(c) {
      const t = c.getTarget() || c.sender
      c.reply(`🔥 @${numOf(t)} ${pick(ROASTS)}\n\n_(es broma, no te la tomes a pecho)_`, [t])
    },
  },
  { name: 'dato', aliases: ['curiosidad', 'sabiasque'], desc: 'Un dato curioso', async run(c) { c.reply(`🧠 *¿Sabías que...?*\n${pick(DATOS)}`) } },
  {
    name: 'adivinanza', aliases: ['riddle', 'acertijo'], desc: 'Una adivinanza (responde con .respuesta)',
    async run(c) {
      const [q, a] = pick(ADIVINANZAS)
      quiz.set(c.from, { answer: norm(a), type: 'text', reward: 60 })
      c.reply(`🤔 *Adivinanza*\n\n${q}\n\nResponde con ${c.prefix}respuesta <tu respuesta>`)
    },
  },
  {
    name: 'prefieres', aliases: ['wyr'], desc: '¿Qué prefieres?',
    async run(c) { const [a, b] = pick(PREFIERES); c.reply(`🤷 *¿Qué prefieres?*\n\n🅰️ ${a}\n🅱️ ${b}`) },
  },
  {
    name: 'pareja', aliases: ['couple'], desc: 'Empareja a dos miembros al azar', group: true,
    async run(c) {
      const [a, b] = memberPick(c, 2)
      if (!b) return c.reply('Se necesitan al menos 2 miembros.')
      c.reply(`💑 La pareja de hoy es @${numOf(a)} + @${numOf(b)} 💕`, [a, b])
    },
  },
  {
    name: 'sorteo', aliases: ['raffle', 'ganador'], desc: 'Elige un ganador al azar', usage: '[premio]', group: true,
    async run(c) {
      const [w] = memberPick(c)
      c.reply(`🎁 *SORTEO*${c.text ? `\nPremio: ${c.text}` : ''}\n\n🏆 Ganador/a: @${numOf(w)}`, [w])
    },
  },
  {
    name: 'top', desc: 'Top 5 de miembros según un tema (aleatorio)', usage: '<tema>', group: true,
    async run(c) {
      if (!c.text) return c.reply(`Uso: ${c.prefix}top los más graciosos`)
      const list = memberPick(c, 5)
      c.reply(`🏅 *TOP ${list.length}: ${c.text}*\n\n` + list.map((j, i) => `${['🥇', '🥈', '🥉', '4️⃣', '5️⃣'][i]} @${numOf(j)}`).join('\n'), list)
    },
  },
  {
    name: 'trivia', aliases: ['quiz'], desc: 'Pregunta de cultura general (responde con .respuesta a/b/c)',
    async run(c) {
      const [q, opts, ans] = pick(TRIVIA)
      quiz.set(c.from, { answer: ans, type: 'letter', reward: 80 })
      c.reply(`🧩 *Trivia*\n\n${q}\n\nA) ${opts[0]}\nB) ${opts[1]}\nC) ${opts[2]}\n\nResponde con ${c.prefix}respuesta a, b o c`)
    },
  },
  {
    name: 'respuesta', aliases: ['resp', 'r'], desc: 'Responde a la trivia o adivinanza activa', usage: '<respuesta>',
    async run(c) {
      const q = quiz.get(c.from)
      if (!q) return c.reply(`No hay ninguna pregunta activa. Usa ${c.prefix}trivia o ${c.prefix}adivinanza`)
      if (!c.text) return c.reply('Escribe tu respuesta.')
      if (norm(c.text) === q.answer) {
        quiz.delete(c.from)
        c.user.coins += q.reward
        return c.reply(`✅ ¡Correcto @${numOf(c.sender)}! Ganaste ${q.reward} monedas 🪙`, [c.sender])
      }
      c.reply('❌ Incorrecto, ¡sigue intentando!')
    },
  },
  {
    name: 'abrazo', aliases: ['hug'], desc: 'Da un abrazo a alguien', usage: '@usuario',
    async run(c) {
      const t = c.getTarget()
      if (!t) return c.reply('Menciona o responde a quien quieras abrazar.')
      c.reply(`🤗 @${numOf(c.sender)} le dio un fuerte abrazo a @${numOf(t)}`, [c.sender, t])
    },
  },
  {
    name: 'golpe', aliases: ['punch', 'pegar'], desc: 'Un golpe amistoso (de broma)', usage: '@usuario',
    async run(c) {
      const t = c.getTarget()
      if (!t) return c.reply('Menciona o responde a la víctima 😈')
      c.reply(`👊 @${numOf(c.sender)} le dio un golpecito juguetón a @${numOf(t)}`, [c.sender, t])
    },
  },
  {
    name: 'ahorcado', aliases: ['hangman'], desc: 'Juego del ahorcado', usage: '[letra]',
    async run(c) {
      const draw = (g) => {
        const shown = [...g.word].map((l) => (g.found.has(l) ? l : '_')).join(' ')
        return `🪢 *Ahorcado*\n\n${shown}\n\n❌ Errores: ${g.wrong.size}/6 ${[...g.wrong].join(' ')}`
      }
      let g = hang.get(c.from)
      const l = norm(c.args[0] || '')
      if (!g || !/^[a-z]$/.test(l)) {
        if (g && !c.args[0]) return c.reply(draw(g) + `\n\nUsa ${c.prefix}ahorcado <letra>`)
        g = { word: pick(WORDS), found: new Set(), wrong: new Set() }
        hang.set(c.from, g)
        return c.reply(draw(g) + `\n\nUsa ${c.prefix}ahorcado <letra>`)
      }
      if (g.found.has(l) || g.wrong.has(l)) return c.reply('Esa letra ya la probaron.')
      if (g.word.includes(l)) g.found.add(l)
      else g.wrong.add(l)
      if ([...g.word].every((x) => g.found.has(x))) {
        hang.delete(c.from)
        c.user.coins += 120
        return c.reply(`🎉 ¡Ganaste! La palabra era *${g.word}*. +120 monedas 🪙`)
      }
      if (g.wrong.size >= 6) { hang.delete(c.from); return c.reply(`💀 Perdiste. La palabra era *${g.word}*.`) }
      c.reply(draw(g))
    },
  },
]
