import os from 'node:os'
import config from '../config.js'
import db from '../lib/db.js'
import { commands } from '../lib/loader.js'
import { clock, fmt, norm, numOf, jidOf } from '../lib/utils.js'

export const category = 'Info'

const byCategory = () => {
  const g = {}
  for (const c of commands.values()) (g[c.category] ||= []).push(c)
  return g
}
const botName = () => db.data.settings.name || config.botName
const ownerJid = () => jidOf(config.owners[0])

export default [
  {
    name: 'menu', aliases: ['help', 'ayuda', 'comandos'], desc: 'Muestra todos los comandos', usage: '[categoría]',
    async run(c) {
      const g = byCategory()
      const p = c.prefix
      const sel = c.args[0] && norm(c.args[0])
      if (sel) {
        const key = Object.keys(g).find((k) => norm(k) === sel)
        if (!key) return c.reply(`❌ Categoría no encontrada. Usa ${p}categorias`)
        const lines = g[key].map((x) => `│ › ${p}${x.name}${x.usage ? ' ' + x.usage : ''}\n│    ${x.desc}`)
        return c.reply(`╭─〔 ${key.toUpperCase()} 〕\n${lines.join('\n')}\n╰────────────`)
      }
      let t = `╭━━━〔 🤖 ${botName()} 〕━━━╮\n`
      t += `┃ 👤 Hola @${numOf(c.sender)}\n┃ ⚙️ Prefijo: ${p}\n┃ 📦 Comandos: ${commands.size}\n`
      t += `┃ ⏱️ Activo: ${clock(process.uptime() * 1000)}\n╰━━━━━━━━━━━━━━━━━━╯\n\n`
      for (const [cat, list] of Object.entries(g)) {
        t += `◈ *${cat.toUpperCase()}* (${list.length})\n${list.map((x) => p + x.name).join(' · ')}\n\n`
      }
      t += `💡 Detalle de una categoría: ${p}menu <categoría>`
      c.reply(t, [c.sender])
    },
  },
  {
    name: 'ping', aliases: ['p', 'speed'], desc: 'Mide la velocidad de respuesta',
    async run(c) {
      const ts = Number(String(c.m.messageTimestamp)) * 1000
      const ms = Math.max(Date.now() - (ts || Date.now()), 0)
      c.reply(`🏓 Pong! *${ms} ms*`)
    },
  },
  {
    name: 'runtime', aliases: ['uptime', 'activo'], desc: 'Tiempo que lleva activo el bot',
    async run(c) { c.reply(`⏱️ Llevo activo: *${clock(process.uptime() * 1000)}*`) },
  },
  {
    name: 'owner', aliases: ['creador', 'dueno'], desc: 'Contacto del dueño del bot',
    async run(c) {
      const num = config.owners[0]
      const vcard = `BEGIN:VCARD\nVERSION:3.0\nFN:Dueño de ${botName()}\nTEL;type=CELL;waid=${num}:+${num}\nEND:VCARD`
      await c.sock.sendMessage(c.from, { contacts: { displayName: 'Dueño', contacts: [{ vcard }] } }, { quoted: c.m })
    },
  },
  {
    name: 'infobot', aliases: ['botinfo', 'info'], desc: 'Información general del bot',
    async run(c) {
      const mem = (process.memoryUsage().rss / 1024 / 1024).toFixed(0)
      c.reply(
        `🤖 *${botName()}*\n\n` +
        `📦 Comandos: ${commands.size}\n👥 Usuarios registrados: ${fmt(Object.keys(db.data.users).length)}\n` +
        `💬 Grupos: ${fmt(Object.keys(db.data.groups).length)}\n⚙️ Prefijo: ${c.prefix}\n` +
        `🟢 Node: ${process.version}\n🧠 RAM: ${mem} MB\n⏱️ Activo: ${clock(process.uptime() * 1000)}`
      )
    },
  },
  {
    name: 'script', aliases: ['sc', 'repo'], desc: 'Enlace al repositorio del bot',
    async run(c) { c.reply(`📂 *Repositorio*\n${config.repo}`) },
  },
  {
    name: 'estado', aliases: ['status', 'servidor'], desc: 'Estado del servidor',
    async run(c) {
      const total = os.totalmem() / 1024 / 1024 / 1024
      const free = os.freemem() / 1024 / 1024 / 1024
      c.reply(
        `🖥️ *Estado del servidor*\n\n` +
        `💻 SO: ${os.platform()} ${os.arch()}\n🧮 CPUs: ${os.cpus().length}\n` +
        `📊 Carga: ${os.loadavg().map((n) => n.toFixed(2)).join(' / ')}\n` +
        `🧠 RAM: ${(total - free).toFixed(2)} / ${total.toFixed(2)} GB\n⏱️ Servidor activo: ${clock(os.uptime() * 1000)}`
      )
    },
  },
  {
    name: 'prefijo', aliases: ['prefix'], desc: 'Muestra los prefijos válidos',
    async run(c) { c.reply(`⚙️ Prefijos: ${(db.data.settings.prefix || config.prefix).join('  ')}`) },
  },
  {
    name: 'donar', aliases: ['donate', 'apoyar'], desc: 'Cómo apoyar el proyecto',
    async run(c) { c.reply(config.donate) },
  },
  {
    name: 'stats', aliases: ['estadisticas'], desc: 'Estadísticas de uso del bot',
    async run(c) {
      const top = Object.entries(db.data.users).sort((a, b) => b[1].cmds - a[1].cmds).slice(0, 5)
      const lines = top.map(([j, u], i) => `${i + 1}. @${numOf(j)} — ${fmt(u.cmds)} comandos`)
      c.reply(`📈 *Estadísticas*\n\nComandos ejecutados: ${fmt(db.data.stats.cmds)}\nUsuarios: ${fmt(Object.keys(db.data.users).length)}\n\n🏆 *Más activos*\n${lines.join('\n') || 'Aún no hay datos'}`, top.map(([j]) => j))
    },
  },
  {
    name: 'buscarcmd', aliases: ['buscar', 'cmd'], desc: 'Busca un comando por nombre o descripción', usage: '<texto>',
    async run(c) {
      if (!c.text) return c.reply(`Uso: ${c.prefix}buscarcmd <texto>`)
      const q = norm(c.text)
      const found = [...commands.values()].filter((x) => norm(x.name + ' ' + x.desc + ' ' + (x.aliases || []).join(' ')).includes(q)).slice(0, 15)
      if (!found.length) return c.reply('❌ No encontré comandos con eso.')
      c.reply(`🔎 *Resultados*\n\n` + found.map((x) => `› ${c.prefix}${x.name} — ${x.desc}`).join('\n'))
    },
  },
  {
    name: 'categorias', aliases: ['categories', 'cats'], desc: 'Lista las categorías de comandos',
    async run(c) {
      const g = byCategory()
      c.reply(`🗂️ *Categorías*\n\n` + Object.entries(g).map(([k, v]) => `› ${k} (${v.length})`).join('\n') + `\n\nUsa ${c.prefix}menu <categoría>`)
    },
  },
  {
    name: 'reportar', aliases: ['report', 'bug'], desc: 'Reporta un error al dueño', usage: '<descripción>',
    async run(c) {
      if (!c.text) return c.reply(`Uso: ${c.prefix}reportar <descripción del error>`)
      await c.sock.sendMessage(ownerJid(), { text: `🐞 *Reporte* de @${numOf(c.sender)}\n\n${c.text}`, mentions: [c.sender] })
      c.reply('✅ Reporte enviado al dueño. ¡Gracias!')
    },
  },
  {
    name: 'sugerir', aliases: ['suggest', 'sugerencia'], desc: 'Envía una sugerencia al dueño', usage: '<idea>',
    async run(c) {
      if (!c.text) return c.reply(`Uso: ${c.prefix}sugerir <tu idea>`)
      await c.sock.sendMessage(ownerJid(), { text: `💡 *Sugerencia* de @${numOf(c.sender)}\n\n${c.text}`, mentions: [c.sender] })
      c.reply('✅ Sugerencia enviada. ¡Gracias!')
    },
  },
]
