import { numOf, jidOf } from '../lib/utils.js'
import { invalidateMeta } from '../lib/cache.js'

export const category = 'Grupo'

const G = { group: true }
const A = { group: true, admin: true }
const BA = { group: true, admin: true, botAdmin: true }

// Crea comandos on/off para ajustes del grupo
const toggle = (name, aliases, desc, field, label) => ({
  name, aliases, desc, usage: 'on/off', ...A,
  async run(c) {
    const v = (c.args[0] || '').toLowerCase()
    if (!['on', 'off'].includes(v)) return c.reply(`Uso: ${c.prefix}${name} on/off\nEstado actual: ${c.group[field] ? 'ON ✅' : 'OFF ❌'}`)
    c.group[field] = v === 'on'
    c.reply(`✅ ${label} ${v === 'on' ? 'activado' : 'desactivado'}.`)
  },
})

export default [
  {
    name: 'kick', aliases: ['expulsar', 'sacar'], desc: 'Expulsa a un miembro', usage: '@usuario', ...BA,
    async run(c) {
      const t = c.getTarget(true)
      if (!t) return c.reply('Menciona, responde o escribe el número del usuario.')
      if (c.admins.includes(t)) return c.reply('❌ No puedo expulsar a un administrador.')
      await c.sock.groupParticipantsUpdate(c.from, [t], 'remove')
      c.reply(`👢 @${numOf(t)} fue expulsado.`, [t])
    },
  },
  {
    name: 'add', aliases: ['agregar', 'anadir'], desc: 'Agrega un número al grupo', usage: '<número>', ...BA,
    async run(c) {
      const digits = c.text.replace(/\D/g, '')
      if (digits.length < 7) return c.reply(`Uso: ${c.prefix}add 50688888888`)
      const res = await c.sock.groupParticipantsUpdate(c.from, [jidOf(digits)], 'add')
      const status = String(res?.[0]?.status)
      if (status === '200') return c.reply('✅ Usuario agregado.')
      if (status === '403') return c.reply('🔒 Esa persona solo permite que la agreguen sus contactos. Envíale el enlace con .link')
      if (status === '409') return c.reply('ℹ️ Ya está en el grupo.')
      c.reply(`❌ No se pudo agregar (código ${status}).`)
    },
  },
  {
    name: 'promote', aliases: ['daradmin'], desc: 'Hace admin a un miembro', usage: '@usuario', ...BA,
    async run(c) {
      const t = c.getTarget(true)
      if (!t) return c.reply('Menciona o responde al usuario.')
      await c.sock.groupParticipantsUpdate(c.from, [t], 'promote')
      c.reply(`👑 @${numOf(t)} ahora es administrador.`, [t])
    },
  },
  {
    name: 'demote', aliases: ['quitaradmin'], desc: 'Quita el admin a un miembro', usage: '@usuario', ...BA,
    async run(c) {
      const t = c.getTarget(true)
      if (!t) return c.reply('Menciona o responde al usuario.')
      await c.sock.groupParticipantsUpdate(c.from, [t], 'demote')
      c.reply(`⬇️ @${numOf(t)} ya no es administrador.`, [t])
    },
  },
  {
    name: 'tagall', aliases: ['todos', 'invocar'], desc: 'Menciona a todos los miembros', usage: '[mensaje]', ...A,
    async run(c) {
      const t = `📢 *${c.text || 'Atención a todos'}*\n\n` + c.participants.map((j) => `› @${numOf(j)}`).join('\n')
      c.reply(t, c.participants)
    },
  },
  {
    name: 'hidetag', aliases: ['notificar', 'n'], desc: 'Menciona a todos sin mostrar la lista', usage: '[mensaje]', ...A,
    async run(c) {
      await c.sock.sendMessage(c.from, { text: c.text || c.quotedText || '📢', mentions: c.participants })
    },
  },
  {
    name: 'link', aliases: ['enlace', 'linkgrupo'], desc: 'Enlace de invitación del grupo', ...BA,
    async run(c) {
      const code = await c.sock.groupInviteCode(c.from)
      c.reply(`🔗 https://chat.whatsapp.com/${code}`)
    },
  },
  {
    name: 'revoke', aliases: ['resetlink', 'revocar'], desc: 'Restablece el enlace del grupo', ...BA,
    async run(c) {
      await c.sock.groupRevokeInvite(c.from)
      c.reply('♻️ Enlace restablecido. Usa .link para ver el nuevo.')
    },
  },
  {
    name: 'abrir', aliases: ['open', 'unlock'], desc: 'Permite que todos escriban', ...BA,
    async run(c) { await c.sock.groupSettingUpdate(c.from, 'not_announcement'); c.reply('🔓 Grupo abierto: todos pueden escribir.') },
  },
  {
    name: 'cerrar', aliases: ['close', 'lock'], desc: 'Solo los admins pueden escribir', ...BA,
    async run(c) { await c.sock.groupSettingUpdate(c.from, 'announcement'); c.reply('🔒 Grupo cerrado: solo escriben los admins.') },
  },
  {
    name: 'setname', aliases: ['nombregrupo'], desc: 'Cambia el nombre del grupo', usage: '<nombre>', ...BA,
    async run(c) {
      if (!c.text) return c.reply(`Uso: ${c.prefix}setname <nuevo nombre>`)
      await c.sock.groupUpdateSubject(c.from, c.text.slice(0, 100))
      invalidateMeta(c.from)
      c.reply('✅ Nombre actualizado.')
    },
  },
  {
    name: 'setdesc', aliases: ['descgrupo'], desc: 'Cambia la descripción del grupo', usage: '<texto>', ...BA,
    async run(c) {
      if (!c.text) return c.reply(`Uso: ${c.prefix}setdesc <descripción>`)
      await c.sock.groupUpdateDescription(c.from, c.text)
      c.reply('✅ Descripción actualizada.')
    },
  },
  toggle('antilink', ['antienlace'], 'Borra y expulsa a quien envíe enlaces de grupos', 'antilink', 'Antilink'),
  toggle('welcome', ['bienvenida'], 'Activa o desactiva la bienvenida', 'welcome', 'Bienvenida'),
  toggle('bye', ['despedida'], 'Activa o desactiva la despedida', 'bye', 'Despedida'),
  {
    name: 'setwelcome', aliases: ['setbienvenida'], desc: 'Personaliza la bienvenida (@user, @group)', usage: '<texto>', ...A,
    async run(c) {
      if (!c.text) return c.reply(`Uso: ${c.prefix}setwelcome Hola @user, bienvenido a @group`)
      c.group.welcomeMsg = c.text
      c.reply('✅ Mensaje de bienvenida guardado. Actívalo con .welcome on')
    },
  },
  {
    name: 'warn', aliases: ['advertir'], desc: 'Advierte a un miembro (3 = expulsión)', usage: '@usuario [motivo]', ...A,
    async run(c) {
      const t = c.getTarget()
      if (!t) return c.reply('Menciona o responde al usuario.')
      if (c.admins.includes(t)) return c.reply('❌ No puedes advertir a un administrador.')
      const n = (c.group.warns[t] = (c.group.warns[t] || 0) + 1)
      if (n >= 3 && c.isBotAdmin) {
        c.group.warns[t] = 0
        await c.sock.groupParticipantsUpdate(c.from, [t], 'remove')
        return c.reply(`🚫 @${numOf(t)} llegó a 3 advertencias y fue expulsado.`, [t])
      }
      c.reply(`⚠️ @${numOf(t)} tiene *${n}/3* advertencias.`, [t])
    },
  },
  {
    name: 'unwarn', aliases: ['quitarwarn'], desc: 'Quita una advertencia', usage: '@usuario', ...A,
    async run(c) {
      const t = c.getTarget()
      if (!t) return c.reply('Menciona o responde al usuario.')
      c.group.warns[t] = Math.max((c.group.warns[t] || 0) - 1, 0)
      c.reply(`✅ @${numOf(t)} ahora tiene *${c.group.warns[t]}/3* advertencias.`, [t])
    },
  },
  {
    name: 'warns', aliases: ['listwarns', 'advertencias'], desc: 'Lista de advertencias del grupo', ...G,
    async run(c) {
      const list = Object.entries(c.group.warns).filter(([, n]) => n > 0)
      if (!list.length) return c.reply('✅ Nadie tiene advertencias.')
      c.reply('⚠️ *Advertencias*\n\n' + list.map(([j, n]) => `› @${numOf(j)}: ${n}/3`).join('\n'), list.map(([j]) => j))
    },
  },
  {
    name: 'admins', aliases: ['listadmins'], desc: 'Lista los administradores', ...G,
    async run(c) { c.reply('👑 *Administradores*\n\n' + c.admins.map((j) => `› @${numOf(j)}`).join('\n'), c.admins) },
  },
  {
    name: 'infogrupo', aliases: ['groupinfo', 'gp'], desc: 'Información del grupo', ...G,
    async run(c) {
      const m = c.meta
      const created = m.creation ? new Date(m.creation * 1000).toLocaleDateString('es-ES') : 'desconocida'
      c.reply(
        `👥 *${m.subject}*\n\n🆔 ${m.id}\n📅 Creado: ${created}\n👤 Miembros: ${c.participants.length}\n👑 Admins: ${c.admins.length}\n` +
        `🔒 Solo admins escriben: ${m.announce ? 'Sí' : 'No'}\n\n📝 ${m.desc || 'Sin descripción'}`
      )
    },
  },
  {
    name: 'del', aliases: ['delete', 'borrar'], desc: 'Borra el mensaje al que respondes', ...BA,
    async run(c) {
      if (!c.quotedId) return c.reply('Responde al mensaje que quieres borrar.')
      await c.sock.sendMessage(c.from, {
        delete: { remoteJid: c.from, fromMe: c.quotedSender === c.botJid, id: c.quotedId, participant: c.quotedSender },
      })
    },
  },
  {
    name: 'mute', aliases: ['silenciar'], desc: 'El bot ignora a los no-admins en este grupo', ...A,
    async run(c) { c.group.muted = true; c.reply('🔇 Bot silenciado para miembros. Usa .unmute para reactivarlo.') },
  },
  {
    name: 'unmute', aliases: ['activar'], desc: 'Reactiva el bot para todos', ...A,
    async run(c) { c.group.muted = false; c.reply('🔊 Bot reactivado para todos.') },
  },
  {
    name: 'setpp', aliases: ['fotogrupo'], desc: 'Cambia la foto del grupo (responde a una imagen)', ...BA,
    async run(c) {
      const media = await c.getMedia()
      if (!media || media.type !== 'imageMessage') return c.reply('Envía o responde a una *imagen* con el comando.')
      await c.sock.updateProfilePicture(c.from, media.buffer)
      c.reply('✅ Foto del grupo actualizada.')
    },
  },
  {
    name: 'tagadmins', aliases: ['@admins', 'llamaradmins'], desc: 'Menciona solo a los admins', usage: '[mensaje]', ...G,
    async run(c) {
      c.reply(`🚨 *${c.text || 'Se necesita a los administradores'}*\n\n` + c.admins.map((j) => `› @${numOf(j)}`).join('\n'), c.admins)
    },
  },
  {
    name: 'topactivos', aliases: ['activos', 'ranking'], desc: 'Miembros que más mensajes han enviado', ...G,
    async run(c) {
      const top = Object.entries(c.group.msgs).sort((a, b) => b[1] - a[1]).slice(0, 10)
      if (!top.length) return c.reply('Aún no hay datos.')
      c.reply('💬 *Más activos*\n\n' + top.map(([j, n], i) => `${i + 1}. @${numOf(j)} — ${n} mensajes`).join('\n'), top.map(([j]) => j))
    },
  },
  {
    name: 'encuesta', aliases: ['poll', 'votacion'], desc: 'Crea una encuesta', usage: 'Pregunta|op1|op2|...', ...G,
    async run(c) {
      const parts = c.text.split('|').map((s) => s.trim()).filter(Boolean)
      if (parts.length < 3) return c.reply(`Uso: ${c.prefix}encuesta ¿Pizza o hamburguesa?|Pizza|Hamburguesa`)
      const [name, ...values] = parts
      await c.sock.sendMessage(c.from, { poll: { name, values: values.slice(0, 12), selectableCount: 1 } })
    },
  },
  {
    name: 'reglas', aliases: ['rules'], desc: 'Muestra las reglas del grupo', ...G,
    async run(c) { c.reply(c.group.rules ? `📜 *Reglas del grupo*\n\n${c.group.rules}` : `📜 Este grupo aún no tiene reglas. Un admin puede usar ${c.prefix}setreglas`) },
  },
  {
    name: 'setreglas', aliases: ['setrules'], desc: 'Define las reglas del grupo', usage: '<texto>', ...A,
    async run(c) {
      if (!c.text) return c.reply(`Uso: ${c.prefix}setreglas <texto de las reglas>`)
      c.group.rules = c.text
      c.reply('✅ Reglas guardadas.')
    },
  },
]
