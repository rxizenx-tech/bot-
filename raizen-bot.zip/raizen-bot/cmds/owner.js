import fs from 'node:fs'
import config from '../config.js'
import db from '../lib/db.js'
import { numOf, sleep, norm } from '../lib/utils.js'

export const category = 'Owner'

const O = { owner: true }

export default [
  {
    name: 'broadcast', aliases: ['bc', 'difusion'], desc: 'Envía un mensaje a todos los grupos', usage: '<mensaje>', ...O,
    async run(c) {
      if (!c.text) return c.reply(`Uso: ${c.prefix}broadcast <mensaje>`)
      const groups = Object.keys(await c.sock.groupFetchAllParticipating())
      await c.reply(`📣 Enviando a ${groups.length} grupos...`)
      let ok = 0
      for (const id of groups) {
        try { await c.sock.sendMessage(id, { text: `📢 *COMUNICADO*\n\n${c.text}` }); ok++ } catch {}
        await sleep(1500)
      }
      c.reply(`✅ Enviado a ${ok}/${groups.length} grupos.`)
    },
  },
  {
    name: 'ban', aliases: ['banear'], desc: 'Bloquea a un usuario del bot', usage: '@usuario', ...O,
    async run(c) {
      const t = c.getTarget(true)
      if (!t) return c.reply('Menciona, responde o escribe el número.')
      if (!db.data.banned.includes(t)) db.data.banned.push(t)
      c.reply(`🔨 @${numOf(t)} ya no puede usar el bot.`, [t])
    },
  },
  {
    name: 'unban', aliases: ['desbanear'], desc: 'Quita el bloqueo a un usuario', usage: '@usuario', ...O,
    async run(c) {
      const t = c.getTarget(true)
      if (!t) return c.reply('Menciona, responde o escribe el número.')
      db.data.banned = db.data.banned.filter((j) => j !== t)
      c.reply(`✅ @${numOf(t)} puede volver a usar el bot.`, [t])
    },
  },
  {
    name: 'banlist', aliases: ['baneados'], desc: 'Lista de usuarios bloqueados', ...O,
    async run(c) {
      const l = db.data.banned
      c.reply(l.length ? '🔨 *Baneados*\n\n' + l.map((j) => `› @${numOf(j)}`).join('\n') : 'No hay usuarios baneados.', l)
    },
  },
  {
    name: 'setprefix', aliases: ['prefijoset'], desc: 'Cambia los prefijos (separa con espacios)', usage: '<. ! #>', ...O,
    async run(c) {
      const list = c.args.filter((a) => a.length <= 2)
      if (!list.length) return c.reply(`Uso: ${c.prefix}setprefix . ! #\nUsa "reset" para volver al original.`)
      db.data.settings.prefix = norm(c.args[0]) === 'reset' ? null : list
      c.reply(`✅ Prefijos: ${(db.data.settings.prefix || config.prefix).join('  ')}`)
    },
  },
  {
    name: 'setnombre', aliases: ['setbotname'], desc: 'Cambia el nombre del bot en los menús', usage: '<nombre>', ...O,
    async run(c) {
      if (!c.text) return c.reply(`Uso: ${c.prefix}setnombre <nombre>`)
      db.data.settings.name = c.text.slice(0, 30)
      c.reply(`✅ Nombre cambiado a *${db.data.settings.name}*`)
    },
  },
  {
    name: 'restart', aliases: ['reiniciar'], desc: 'Reinicia el bot', ...O,
    async run(c) {
      await c.reply('🔄 Reiniciando...')
      db.save()
      setTimeout(() => process.exit(0), 800)
    },
  },
  {
    name: 'salir', aliases: ['leave'], desc: 'El bot abandona este grupo', group: true, ...O,
    async run(c) {
      await c.reply('👋 ¡Hasta pronto!')
      await c.sock.groupLeave(c.from)
    },
  },
  {
    name: 'unirse', aliases: ['join'], desc: 'El bot entra a un grupo por enlace', usage: '<enlace>', ...O,
    async run(c) {
      const m = /chat\.whatsapp\.com\/([A-Za-z0-9]+)/.exec(c.text)
      if (!m) return c.reply(`Uso: ${c.prefix}unirse https://chat.whatsapp.com/XXXX`)
      await c.sock.groupAcceptInvite(m[1])
      c.reply('✅ Me uní al grupo.')
    },
  },
  {
    name: 'bloquear', aliases: ['block'], desc: 'Bloquea un contacto en WhatsApp', usage: '@usuario', ...O,
    async run(c) {
      const t = c.getTarget(true)
      if (!t) return c.reply('Menciona, responde o escribe el número.')
      await c.sock.updateBlockStatus(t, 'block')
      c.reply(`🚫 @${numOf(t)} bloqueado.`, [t])
    },
  },
  {
    name: 'desbloquear', aliases: ['unblock'], desc: 'Desbloquea un contacto en WhatsApp', usage: '@usuario', ...O,
    async run(c) {
      const t = c.getTarget(true)
      if (!t) return c.reply('Menciona, responde o escribe el número.')
      await c.sock.updateBlockStatus(t, 'unblock')
      c.reply(`✅ @${numOf(t)} desbloqueado.`, [t])
    },
  },
  {
    name: 'modo', aliases: ['mode'], desc: 'Modo público o privado', usage: 'public|private', ...O,
    async run(c) {
      const v = (c.args[0] || '').toLowerCase()
      if (!['public', 'private'].includes(v)) return c.reply(`Uso: ${c.prefix}modo public|private\nActual: ${db.data.settings.mode || config.mode}`)
      db.data.settings.mode = v
      c.reply(`✅ Modo *${v === 'public' ? 'público' : 'privado (solo dueños)'}*.`)
    },
  },
  {
    name: 'backup', aliases: ['respaldo'], desc: 'Envía una copia de la base de datos', ...O,
    async run(c) {
      db.save()
      await c.send({
        document: fs.readFileSync('database.json'),
        fileName: `backup-${new Date().toISOString().slice(0, 10)}.json`,
        mimetype: 'application/json',
      })
    },
  },
]
