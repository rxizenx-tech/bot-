import { getJSON, getText, fmt } from '../lib/utils.js'

export const category = 'Internet'

const need = (c, u) => c.reply(`Uso: ${c.prefix}${c.command} ${u}`)
const fail = (c, e) => c.reply(`❌ No pude obtener los datos (${e.message}). Intenta de nuevo más tarde.`)

const COINS = { btc: 'bitcoin', eth: 'ethereum', sol: 'solana', bnb: 'binancecoin', xrp: 'ripple', doge: 'dogecoin', ada: 'cardano', ltc: 'litecoin', usdt: 'tether' }

export default [
  {
    name: 'clima', aliases: ['weather', 'tiempo'], desc: 'Clima actual de una ciudad', usage: '<ciudad>',
    async run(c) {
      if (!c.text) return need(c, 'San José')
      try {
        const d = await getJSON(`https://wttr.in/${encodeURIComponent(c.text)}?format=j1&lang=es`)
        const w = d.current_condition[0]
        const area = d.nearest_area?.[0]?.areaName?.[0]?.value || c.text
        c.reply(
          `🌤️ *Clima en ${area}*\n\n${w.lang_es?.[0]?.value || w.weatherDesc[0].value}\n` +
          `🌡️ ${w.temp_C}°C (sensación ${w.FeelsLikeC}°C)\n💧 Humedad: ${w.humidity}%\n💨 Viento: ${w.windspeedKmph} km/h\n☁️ Nubes: ${w.cloudcover}%`
        )
      } catch (e) { fail(c, e) }
    },
  },
  {
    name: 'wiki', aliases: ['wikipedia'], desc: 'Resumen de Wikipedia', usage: '<tema>',
    async run(c) {
      if (!c.text) return need(c, 'Albert Einstein')
      try {
        const s = await getJSON(`https://es.wikipedia.org/w/api.php?action=opensearch&search=${encodeURIComponent(c.text)}&limit=1&format=json`)
        const title = s?.[1]?.[0]
        if (!title) return c.reply('❌ No encontré nada en Wikipedia.')
        const d = await getJSON(`https://es.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title)}`)
        const txt = d.extract.length > 700 ? d.extract.slice(0, 700) + '…' : d.extract
        c.reply(`📚 *${d.title}*\n\n${txt}\n\n🔗 ${d.content_urls?.desktop?.page || ''}`)
      } catch (e) { fail(c, e) }
    },
  },
  {
    name: 'definir', aliases: ['define', 'diccionario'], desc: 'Definición de una palabra (español)', usage: '<palabra>',
    async run(c) {
      if (!c.args[0]) return need(c, 'casa')
      try {
        const d = await getJSON(`https://api.dictionaryapi.dev/v2/entries/es/${encodeURIComponent(c.args[0])}`)
        const lines = []
        for (const m of d[0].meanings.slice(0, 3)) {
          lines.push(`_${m.partOfSpeech}_`)
          m.definitions.slice(0, 2).forEach((x, i) => lines.push(`${i + 1}. ${x.definition}`))
        }
        c.reply(`📖 *${d[0].word}*\n\n${lines.join('\n')}`)
      } catch { c.reply('❌ No encontré esa palabra.') }
    },
  },
  {
    name: 'pais', aliases: ['country'], desc: 'Datos de un país', usage: '<país>',
    async run(c) {
      if (!c.text) return need(c, 'Costa Rica')
      try {
        const d = (await getJSON(`https://restcountries.com/v3.1/translation/${encodeURIComponent(c.text)}?fields=name,capital,region,population,languages,currencies,area,flag`))[0]
        const cur = Object.values(d.currencies || {}).map((x) => `${x.name} (${x.symbol || ''})`).join(', ')
        c.reply(
          `${d.flag} *${d.name.common}*\n\n🏛️ Capital: ${(d.capital || []).join(', ') || '—'}\n🌎 Región: ${d.region}\n` +
          `👥 Población: ${fmt(d.population)}\n📐 Área: ${fmt(d.area)} km²\n🗣️ Idiomas: ${Object.values(d.languages || {}).join(', ')}\n💱 Moneda: ${cur}`
        )
      } catch { c.reply('❌ No encontré ese país.') }
    },
  },
  {
    name: 'cripto', aliases: ['crypto', 'precio'], desc: 'Precio de una criptomoneda', usage: '<btc|eth|sol...>',
    async run(c) {
      const q = (c.args[0] || 'btc').toLowerCase()
      const id = COINS[q] || q
      try {
        const d = await getJSON(`https://api.coingecko.com/api/v3/simple/price?ids=${encodeURIComponent(id)}&vs_currencies=usd,eur&include_24hr_change=true`)
        const r = d[id]
        if (!r) return c.reply(`❌ Moneda no encontrada. Prueba con: ${Object.keys(COINS).join(', ')}`)
        const ch = r.usd_24h_change
        c.reply(`🪙 *${id.toUpperCase()}*\n\n💵 USD: $${fmt(r.usd)}\n💶 EUR: €${fmt(r.eur)}\n${ch >= 0 ? '📈' : '📉'} 24h: ${ch?.toFixed(2)}%`)
      } catch (e) { fail(c, e) }
    },
  },
  {
    name: 'divisa', aliases: ['cambio', 'exchange'], desc: 'Convierte entre monedas', usage: '<cantidad> <USD> <CRC>',
    async run(c) {
      const amt = Number(c.args[0])
      const from = (c.args[1] || '').toUpperCase()
      const to = (c.args[2] || '').toUpperCase()
      if (isNaN(amt) || !from || !to) return need(c, '100 USD CRC')
      try {
        const d = await getJSON(`https://open.er-api.com/v6/latest/${from}`)
        const rate = d.rates?.[to]
        if (!rate) return c.reply('❌ Código de moneda no válido.')
        c.reply(`💱 ${fmt(amt)} ${from} = *${fmt(+(amt * rate).toFixed(2))} ${to}*\n_Tasa: 1 ${from} = ${rate} ${to}_`)
      } catch (e) { fail(c, e) }
    },
  },
  {
    name: 'ip', aliases: ['iplookup'], desc: 'Información de una dirección IP', usage: '<ip>',
    async run(c) {
      if (!c.args[0]) return need(c, '8.8.8.8')
      try {
        const d = await getJSON(`https://ipwho.is/${encodeURIComponent(c.args[0])}`)
        if (!d.success) return c.reply('❌ IP no válida.')
        c.reply(`🌐 *${d.ip}*\n\n📍 ${d.city}, ${d.region}, ${d.country} ${d.flag?.emoji || ''}\n🏢 ISP: ${d.connection?.isp || '—'}\n🕒 Zona: ${d.timezone?.id || '—'}`)
      } catch (e) { fail(c, e) }
    },
  },
  {
    name: 'github', aliases: ['gh'], desc: 'Perfil de un usuario de GitHub', usage: '<usuario>',
    async run(c) {
      if (!c.args[0]) return need(c, 'torvalds')
      try {
        const d = await getJSON(`https://api.github.com/users/${encodeURIComponent(c.args[0])}`)
        c.reply(
          `🐙 *${d.name || d.login}* (@${d.login})\n\n${d.bio || ''}\n\n📦 Repos: ${d.public_repos}\n👥 Seguidores: ${fmt(d.followers)}\n` +
          `📍 ${d.location || '—'}\n🔗 ${d.html_url}`
        )
      } catch { c.reply('❌ Usuario no encontrado.') }
    },
  },
  {
    name: 'acortar', aliases: ['short', 'tinyurl'], desc: 'Acorta un enlace', usage: '<url>',
    async run(c) {
      if (!/^https?:\/\//i.test(c.args[0] || '')) return need(c, 'https://ejemplo.com/enlace-largo')
      try { c.reply(`🔗 ${(await getText(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(c.args[0])}`)).trim()}`) } catch (e) { fail(c, e) }
    },
  },
  {
    name: 'perro', aliases: ['dog'], desc: 'Foto aleatoria de un perro',
    async run(c) {
      try {
        const d = await getJSON('https://dog.ceo/api/breeds/image/random')
        await c.send({ image: { url: d.message }, caption: '🐶 ¡Guau!' })
      } catch (e) { fail(c, e) }
    },
  },
  {
    name: 'gato', aliases: ['cat'], desc: 'Foto aleatoria de un gato',
    async run(c) {
      try {
        const d = await getJSON('https://api.thecatapi.com/v1/images/search')
        await c.send({ image: { url: d[0].url }, caption: '🐱 ¡Miau!' })
      } catch (e) { fail(c, e) }
    },
  },
  {
    name: 'npm', aliases: ['paquete'], desc: 'Información de un paquete de npm', usage: '<paquete>',
    async run(c) {
      if (!c.args[0]) return need(c, 'express')
      try {
        const d = await getJSON(`https://registry.npmjs.org/${encodeURIComponent(c.args[0])}/latest`)
        c.reply(`📦 *${d.name}* v${d.version}\n\n${d.description || ''}\n\n📜 Licencia: ${d.license || '—'}\n🔗 https://www.npmjs.com/package/${d.name}`)
      } catch { c.reply('❌ Paquete no encontrado.') }
    },
  },
]
