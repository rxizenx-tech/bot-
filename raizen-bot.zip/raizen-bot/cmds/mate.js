export const category = 'Matemáticas'

const nums = (c) => c.args.map(Number).filter((n) => !isNaN(n))
const usage = (c, u) => c.reply(`Uso: ${c.prefix}${c.command} ${u}`)
const round = (n) => +Number(n).toFixed(6)
const gcd = (a, b) => { a = Math.abs(a); b = Math.abs(b); while (b) [a, b] = [b, a % b]; return a }

// Conversor simple de una sola unidad
const conv = (name, aliases, desc, fn, from, to) => ({
  name, aliases, desc, usage: '<número>',
  async run(c) {
    const v = Number(c.args[0])
    if (c.args[0] === undefined || isNaN(v)) return usage(c, '<número>')
    c.reply(`🔁 ${v} ${from} = *${round(fn(v))}* ${to}`)
  },
})

// Operación aritmética sobre una lista de números
const op = (name, aliases, desc, symbol, fn) => ({
  name, aliases, desc, usage: '<n1> <n2> ...',
  async run(c) {
    const n = nums(c)
    if (n.length < 2) return usage(c, '<n1> <n2> ...')
    const r = n.reduce(fn)
    c.reply(`🧮 ${n.join(` ${symbol} `)} = *${round(r)}*`)
  },
})

const ROMAN = [[1000, 'M'], [900, 'CM'], [500, 'D'], [400, 'CD'], [100, 'C'], [90, 'XC'], [50, 'L'], [40, 'XL'], [10, 'X'], [9, 'IX'], [5, 'V'], [4, 'IV'], [1, 'I']]
const ROMAN_VAL = { I: 1, V: 5, X: 10, L: 50, C: 100, D: 500, M: 1000 }

export default [
  op('suma', ['sumar', 'add2'], 'Suma varios números', '+', (a, b) => a + b),
  op('resta', ['restar'], 'Resta varios números', '-', (a, b) => a - b),
  op('multiplica', ['multiplicar', 'mult'], 'Multiplica varios números', '×', (a, b) => a * b),
  {
    name: 'divide', aliases: ['dividir'], desc: 'Divide dos o más números', usage: '<n1> <n2>',
    async run(c) {
      const n = nums(c)
      if (n.length < 2) return usage(c, '<n1> <n2>')
      if (n.slice(1).includes(0)) return c.reply('❌ No se puede dividir entre cero.')
      c.reply(`🧮 ${n.join(' ÷ ')} = *${round(n.reduce((a, b) => a / b))}*`)
    },
  },
  {
    name: 'potencia', aliases: ['pow'], desc: 'Eleva una base a un exponente', usage: '<base> <exponente>',
    async run(c) {
      const [b, e] = nums(c)
      if (b === undefined || e === undefined) return usage(c, '<base> <exponente>')
      c.reply(`⚡ ${b}^${e} = *${round(Math.pow(b, e))}*`)
    },
  },
  {
    name: 'raiz', aliases: ['sqrt'], desc: 'Raíz de un número (índice opcional)', usage: '<número> [índice]',
    async run(c) {
      const [n, idx = 2] = nums(c)
      if (n === undefined) return usage(c, '<número> [índice]')
      if (n < 0 && idx % 2 === 0) return c.reply('❌ No hay raíz real de un negativo con índice par.')
      const r = n < 0 ? -Math.pow(-n, 1 / idx) : Math.pow(n, 1 / idx)
      c.reply(`√ Raíz de índice ${idx} de ${n} = *${round(r)}*`)
    },
  },
  {
    name: 'factorial', aliases: ['fact'], desc: 'Factorial de un número (hasta 500)', usage: '<n>',
    async run(c) {
      const n = parseInt(c.args[0])
      if (isNaN(n) || n < 0 || n > 500) return usage(c, '<0-500>')
      let r = 1n
      for (let i = 2n; i <= BigInt(n); i++) r *= i
      const s = r.toString()
      c.reply(`❗ ${n}! = *${s.length > 300 ? s.slice(0, 300) + `… (${s.length} dígitos)` : s}*`)
    },
  },
  {
    name: 'fibonacci', aliases: ['fib'], desc: 'Término n de Fibonacci (hasta 1000)', usage: '<n>',
    async run(c) {
      const n = parseInt(c.args[0])
      if (isNaN(n) || n < 0 || n > 1000) return usage(c, '<0-1000>')
      let a = 0n, b = 1n
      for (let i = 0; i < n; i++) [a, b] = [b, a + b]
      const s = a.toString()
      c.reply(`🌀 Fibonacci(${n}) = *${s.length > 300 ? s.slice(0, 300) + '…' : s}*`)
    },
  },
  {
    name: 'primo', aliases: ['isprime'], desc: 'Dice si un número es primo', usage: '<número>',
    async run(c) {
      const n = Number(c.args[0])
      if (!Number.isInteger(n) || n < 0 || n > 1e12) return usage(c, '<entero hasta 1e12>')
      if (n < 2) return c.reply(`🔢 ${n} no es primo.`)
      for (let i = 2; i * i <= n; i++) {
        if (n % i === 0) return c.reply(`🔢 ${n} *no* es primo (divisible entre ${i}).`)
      }
      c.reply(`✅ ${n} *es primo*.`)
    },
  },
  {
    name: 'mcd', aliases: ['gcd'], desc: 'Máximo común divisor', usage: '<n1> <n2> ...',
    async run(c) {
      const n = nums(c).map(Math.trunc)
      if (n.length < 2) return usage(c, '<n1> <n2> ...')
      c.reply(`🔢 MCD(${n.join(', ')}) = *${n.reduce(gcd)}*`)
    },
  },
  {
    name: 'mcm', aliases: ['lcm'], desc: 'Mínimo común múltiplo', usage: '<n1> <n2> ...',
    async run(c) {
      const n = nums(c).map(Math.trunc)
      if (n.length < 2 || n.includes(0)) return usage(c, '<n1> <n2> ... (sin ceros)')
      c.reply(`🔢 MCM(${n.join(', ')}) = *${n.reduce((a, b) => Math.abs(a * b) / gcd(a, b))}*`)
    },
  },
  {
    name: 'porcentaje', aliases: ['porc', 'percent'], desc: 'Calcula el X% de una cantidad', usage: '<porcentaje> <cantidad>',
    async run(c) {
      const [p, n] = nums(c)
      if (p === undefined || n === undefined) return usage(c, '20 150')
      c.reply(`📊 El ${p}% de ${n} es *${round((p / 100) * n)}*\n➕ Sumado: ${round(n * (1 + p / 100))}\n➖ Restado: ${round(n * (1 - p / 100))}`)
    },
  },
  {
    name: 'promedio', aliases: ['media', 'avg'], desc: 'Promedio de una lista de números', usage: '<n1> <n2> ...',
    async run(c) {
      const n = nums(c)
      if (!n.length) return usage(c, '<n1> <n2> ...')
      c.reply(`📊 Promedio de ${n.length} números: *${round(n.reduce((a, b) => a + b, 0) / n.length)}*`)
    },
  },
  {
    name: 'mediana', aliases: ['median'], desc: 'Mediana de una lista de números', usage: '<n1> <n2> ...',
    async run(c) {
      const n = nums(c).sort((a, b) => a - b)
      if (!n.length) return usage(c, '<n1> <n2> ...')
      const mid = Math.floor(n.length / 2)
      c.reply(`📊 Mediana: *${n.length % 2 ? n[mid] : round((n[mid - 1] + n[mid]) / 2)}*`)
    },
  },
  {
    name: 'areacirculo', aliases: ['circulo'], desc: 'Área y perímetro de un círculo', usage: '<radio>',
    async run(c) {
      const r = Number(c.args[0])
      if (isNaN(r) || r < 0) return usage(c, '<radio>')
      c.reply(`⭕ Radio ${r}\nÁrea: *${round(Math.PI * r * r)}*\nPerímetro: *${round(2 * Math.PI * r)}*`)
    },
  },
  {
    name: 'arearect', aliases: ['rectangulo'], desc: 'Área y perímetro de un rectángulo', usage: '<base> <altura>',
    async run(c) {
      const [b, h] = nums(c)
      if (b === undefined || h === undefined) return usage(c, '<base> <altura>')
      c.reply(`▭ ${b} × ${h}\nÁrea: *${round(b * h)}*\nPerímetro: *${round(2 * (b + h))}*`)
    },
  },
  {
    name: 'areatriangulo', aliases: ['triangulo'], desc: 'Área de un triángulo', usage: '<base> <altura>',
    async run(c) {
      const [b, h] = nums(c)
      if (b === undefined || h === undefined) return usage(c, '<base> <altura>')
      c.reply(`△ Base ${b}, altura ${h}\nÁrea: *${round((b * h) / 2)}*`)
    },
  },
  conv('c2f', ['celsius'], 'Celsius a Fahrenheit', (v) => (v * 9) / 5 + 32, '°C', '°F'),
  conv('f2c', ['fahrenheit'], 'Fahrenheit a Celsius', (v) => ((v - 32) * 5) / 9, '°F', '°C'),
  conv('km2mi', ['km2millas'], 'Kilómetros a millas', (v) => v * 0.621371, 'km', 'mi'),
  conv('mi2km', ['millas2km'], 'Millas a kilómetros', (v) => v / 0.621371, 'mi', 'km'),
  conv('kg2lb', ['kilos2libras'], 'Kilogramos a libras', (v) => v * 2.204623, 'kg', 'lb'),
  conv('lb2kg', ['libras2kilos'], 'Libras a kilogramos', (v) => v / 2.204623, 'lb', 'kg'),
  conv('m2ft', ['metros2pies'], 'Metros a pies', (v) => v * 3.28084, 'm', 'ft'),
  conv('ft2m', ['pies2metros'], 'Pies a metros', (v) => v / 3.28084, 'ft', 'm'),
  {
    name: 'bin2dec', desc: 'Binario a decimal', usage: '<binario>',
    async run(c) {
      if (!/^[01]+$/.test(c.args[0] || '')) return usage(c, '1011')
      c.reply(`🔁 ${c.args[0]} (bin) = *${parseInt(c.args[0], 2)}* (dec)`)
    },
  },
  {
    name: 'dec2bin', desc: 'Decimal a binario', usage: '<número>',
    async run(c) {
      const n = parseInt(c.args[0])
      if (isNaN(n) || n < 0) return usage(c, '11')
      c.reply(`🔁 ${n} (dec) = *${n.toString(2)}* (bin)`)
    },
  },
  {
    name: 'dec2hex', desc: 'Decimal a hexadecimal', usage: '<número>',
    async run(c) {
      const n = parseInt(c.args[0])
      if (isNaN(n) || n < 0) return usage(c, '255')
      c.reply(`🔁 ${n} (dec) = *${n.toString(16).toUpperCase()}* (hex)`)
    },
  },
  {
    name: 'romano', aliases: ['roman'], desc: 'Número a romano o romano a número', usage: '<número | romano>',
    async run(c) {
      const s = (c.args[0] || '').toUpperCase()
      if (/^\d+$/.test(s)) {
        let n = parseInt(s)
        if (n < 1 || n > 3999) return c.reply('❌ Usa un número entre 1 y 3999.')
        let out = ''
        for (const [v, r] of ROMAN) while (n >= v) { out += r; n -= v }
        return c.reply(`🏛️ ${s} = *${out}*`)
      }
      if (/^[IVXLCDM]+$/.test(s)) {
        let t = 0
        for (let i = 0; i < s.length; i++) {
          const v = ROMAN_VAL[s[i]], nx = ROMAN_VAL[s[i + 1]] || 0
          t += v < nx ? -v : v
        }
        return c.reply(`🏛️ ${s} = *${t}*`)
      }
      usage(c, '<número | romano>')
    },
  },
  {
    name: 'imc', aliases: ['bmi'], desc: 'Índice de masa corporal', usage: '<peso kg> <altura m>',
    async run(c) {
      const [w, h] = nums(c)
      if (!w || !h || h > 3) return usage(c, '70 1.75')
      const v = w / (h * h)
      const cat = v < 18.5 ? 'Bajo peso' : v < 25 ? 'Peso normal' : v < 30 ? 'Sobrepeso' : 'Obesidad'
      c.reply(`⚖️ IMC: *${v.toFixed(1)}* — ${cat}\n\n_Es solo una referencia general; consulta a un profesional de salud._`)
    },
  },
]
