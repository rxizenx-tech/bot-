import { pick, rand, fmt, clock, cooldownLeft, numOf, norm } from '../lib/utils.js'

export const category = 'Economía'

const MIN = 60_000
const HOUR = 60 * MIN
const DAY = 24 * HOUR

const SHOP = {
  pico: { price: 1500, desc: 'Duplica lo que ganas con .mine' },
  cana: { price: 1200, desc: 'Duplica lo que ganas con .fish' },
  rifle: { price: 2000, desc: 'Duplica lo que ganas con .hunt' },
  escudo: { price: 800, desc: 'Bloquea un intento de robo (se consume)' },
}
const SELL = { gema: 400, pez: 60, carne: 80 }

const wait = (c, key, ms) => {
  const left = cooldownLeft(c.user[key], ms)
  if (left > 0) { c.reply(`⏳ Espera *${clock(left)}* para volver a usar este comando.`); return true }
  c.user[key] = Date.now()
  return false
}
const amount = (c, raw, max) => {
  if (!raw) return NaN
  if (['all', 'todo'].includes(raw.toLowerCase())) return max
  const n = Math.floor(Number(raw))
  return n > 0 ? n : NaN
}
const mult = (c, tool) => (c.user.inv[tool] ? 2 : 1)

export default [
  {
    name: 'balance', aliases: ['bal', 'cartera', 'monedas'], desc: 'Tu dinero (o el de otro)', usage: '[@usuario]',
    async run(c) {
      const t = c.getTarget() || c.sender
      const u = c.db.user(t)
      c.reply(`💰 *Balance de @${numOf(t)}*\n\n👛 Cartera: ${fmt(u.coins)}\n🏦 Banco: ${fmt(u.bank)}\n💎 Total: ${fmt(u.coins + u.bank)}`, [t])
    },
  },
  {
    name: 'daily', aliases: ['diario'], desc: 'Recompensa diaria',
    async run(c) {
      if (wait(c, 'lastDaily', DAY)) return
      const n = rand(500, 1000)
      c.user.coins += n
      c.reply(`🎁 Recompensa diaria: *+${fmt(n)}* monedas 🪙`)
    },
  },
  {
    name: 'weekly', aliases: ['semanal'], desc: 'Recompensa semanal',
    async run(c) {
      if (wait(c, 'lastWeekly', 7 * DAY)) return
      const n = rand(3000, 5000)
      c.user.coins += n
      c.reply(`🎁 Recompensa semanal: *+${fmt(n)}* monedas 🪙`)
    },
  },
  {
    name: 'work', aliases: ['trabajar', 'chambear'], desc: 'Trabaja para ganar monedas (cada 1h)',
    async run(c) {
      if (wait(c, 'lastWork', HOUR)) return
      const jobs = ['programaste una web', 'repartiste pizzas', 'diseñaste un logo', 'cuidaste mascotas', 'arreglaste computadoras', 'diste clases particulares']
      const n = rand(100, 400)
      c.user.coins += n
      c.reply(`💼 ${pick(jobs)} y ganaste *${fmt(n)}* monedas 🪙`)
    },
  },
  {
    name: 'mine', aliases: ['minar'], desc: 'Mina para ganar monedas y gemas (cada 30 min)',
    async run(c) {
      if (wait(c, 'lastMine', 30 * MIN)) return
      const n = rand(150, 500) * mult(c, 'pico')
      c.user.coins += n
      let extra = ''
      if (Math.random() < 0.15) { c.user.inv.gema = (c.user.inv.gema || 0) + 1; extra = '\n💎 ¡Encontraste una *gema*!' }
      c.reply(`⛏️ Minaste y ganaste *${fmt(n)}* monedas 🪙${extra}`)
    },
  },
  {
    name: 'crime', aliases: ['crimen'], desc: 'Arriesga dinero en un "trabajito" (cada 1h)',
    async run(c) {
      if (wait(c, 'lastCrime', HOUR)) return
      if (Math.random() < 0.5) {
        const n = rand(300, 800)
        c.user.coins += n
        return c.reply(`🕶️ El plan salió bien: *+${fmt(n)}* monedas 🪙`)
      }
      const n = Math.min(rand(100, 400), c.user.coins)
      c.user.coins -= n
      c.reply(`🚨 Te atraparon y pagaste una multa de *${fmt(n)}* monedas.`)
    },
  },
  {
    name: 'fish', aliases: ['pescar'], desc: 'Pesca para ganar monedas (cada 20 min)',
    async run(c) {
      if (wait(c, 'lastFish', 20 * MIN)) return
      const k = mult(c, 'cana')
      const fish = rand(1, 3) * k
      c.user.inv.pez = (c.user.inv.pez || 0) + fish
      const n = rand(30, 120) * k
      c.user.coins += n
      c.reply(`🎣 Pescaste *${fish}* pez(es) y ganaste *${fmt(n)}* monedas 🪙`)
    },
  },
  {
    name: 'hunt', aliases: ['cazar'], desc: 'Caza para ganar monedas (cada 20 min)',
    async run(c) {
      if (wait(c, 'lastHunt', 20 * MIN)) return
      const k = mult(c, 'rifle')
      const meat = rand(1, 3) * k
      c.user.inv.carne = (c.user.inv.carne || 0) + meat
      const n = rand(40, 150) * k
      c.user.coins += n
      c.reply(`🏹 Cazaste *${meat}* pieza(s) de carne y ganaste *${fmt(n)}* monedas 🪙`)
    },
  },
  {
    name: 'cofre', aliases: ['chest'], desc: 'Abre un cofre misterioso (cada 4h)',
    async run(c) {
      if (wait(c, 'lastChest', 4 * HOUR)) return
      const n = rand(200, 1200)
      c.user.coins += n
      c.reply(`🧰 El cofre tenía *${fmt(n)}* monedas 🪙`)
    },
  },
  {
    name: 'deposit', aliases: ['depositar', 'dep'], desc: 'Guarda monedas en el banco', usage: '<cantidad|all>',
    async run(c) {
      const n = amount(c, c.args[0], c.user.coins)
      if (isNaN(n)) return c.reply(`Uso: ${c.prefix}deposit <cantidad|all>`)
      if (n > c.user.coins) return c.reply('❌ No tienes tanto en la cartera.')
      c.user.coins -= n; c.user.bank += n
      c.reply(`🏦 Depositaste *${fmt(n)}* monedas.`)
    },
  },
  {
    name: 'withdraw', aliases: ['retirar', 'with'], desc: 'Saca monedas del banco', usage: '<cantidad|all>',
    async run(c) {
      const n = amount(c, c.args[0], c.user.bank)
      if (isNaN(n)) return c.reply(`Uso: ${c.prefix}withdraw <cantidad|all>`)
      if (n > c.user.bank) return c.reply('❌ No tienes tanto en el banco.')
      c.user.bank -= n; c.user.coins += n
      c.reply(`👛 Retiraste *${fmt(n)}* monedas.`)
    },
  },
  {
    name: 'transfer', aliases: ['dar', 'pagar'], desc: 'Envía monedas a otro usuario', usage: '@usuario <cantidad>',
    async run(c) {
      const t = c.getTarget()
      const n = amount(c, c.args.find((a) => /^\d+$/.test(a)) || c.args[c.args.length - 1], c.user.coins)
      if (!t || isNaN(n)) return c.reply(`Uso: ${c.prefix}transfer @usuario 500`)
      if (t === c.sender) return c.reply('❌ No puedes enviarte monedas a ti mismo.')
      if (n > c.user.coins) return c.reply('❌ No tienes tanto en la cartera.')
      c.user.coins -= n
      c.db.user(t).coins += n
      c.reply(`💸 Enviaste *${fmt(n)}* monedas a @${numOf(t)}.`, [t])
    },
  },
  {
    name: 'rob', aliases: ['robar'], desc: 'Intenta robar a otro usuario (cada 2h)', usage: '@usuario',
    async run(c) {
      const t = c.getTarget()
      if (!t || t === c.sender) return c.reply('Menciona o responde a quién quieres robar.')
      const v = c.db.user(t)
      if (v.coins < 200) return c.reply('😅 Esa persona casi no tiene nada en la cartera.')
      if (wait(c, 'lastRob', 2 * HOUR)) return
      if (v.inv.escudo) {
        v.inv.escudo--
        return c.reply(`🛡️ @${numOf(t)} tenía un escudo y bloqueó el robo.`, [t])
      }
      if (Math.random() < 0.4) {
        const n = Math.floor(v.coins * (rand(10, 30) / 100))
        v.coins -= n; c.user.coins += n
        return c.reply(`🥷 Le robaste *${fmt(n)}* monedas a @${numOf(t)}.`, [t])
      }
      const n = Math.min(rand(100, 300), c.user.coins)
      c.user.coins -= n
      c.reply(`🚔 Te descubrieron y pagaste *${fmt(n)}* monedas de multa.`)
    },
  },
  {
    name: 'apostar', aliases: ['bet', 'gamble'], desc: 'Apuesta monedas (45% de ganar)', usage: '<cantidad|all>',
    async run(c) {
      const n = amount(c, c.args[0], c.user.coins)
      if (isNaN(n)) return c.reply(`Uso: ${c.prefix}apostar <cantidad|all>`)
      if (n > c.user.coins) return c.reply('❌ No tienes tanto en la cartera.')
      if (Math.random() < 0.45) { c.user.coins += n; return c.reply(`🎰 ¡Ganaste! *+${fmt(n)}* monedas 🪙`) }
      c.user.coins -= n
      c.reply(`💥 Perdiste *${fmt(n)}* monedas.`)
    },
  },
  {
    name: 'leaderboard', aliases: ['topmonedas', 'lb', 'toprico'], desc: 'Los más ricos del bot',
    async run(c) {
      const top = Object.entries(c.db.data.users).sort((a, b) => b[1].coins + b[1].bank - (a[1].coins + a[1].bank)).slice(0, 10)
      c.reply('🏆 *Los más ricos*\n\n' + top.map(([j, u], i) => `${i + 1}. @${numOf(j)} — ${fmt(u.coins + u.bank)} 🪙`).join('\n'), top.map(([j]) => j))
    },
  },
  {
    name: 'nivel', aliases: ['level', 'xp', 'rank'], desc: 'Tu nivel y experiencia',
    async run(c) {
      const need = c.user.level * 150
      const pct = Math.min(Math.round((c.user.xp / need) * 10), 10)
      c.reply(`⭐ *Nivel ${c.user.level}*\n[${'█'.repeat(pct)}${'░'.repeat(10 - pct)}] ${c.user.xp}/${need} XP`)
    },
  },
  {
    name: 'perfil', aliases: ['profile', 'yo'], desc: 'Tu perfil (o el de otro)', usage: '[@usuario]',
    async run(c) {
      const t = c.getTarget() || c.sender
      const u = c.db.user(t)
      c.reply(
        `👤 *Perfil*\n\nNombre: ${u.name || 'Sin nombre'}\nNúmero: @${numOf(t)}\nBio: ${u.bio || 'Sin bio'}\n\n` +
        `⭐ Nivel: ${u.level} (${u.xp} XP)\n💰 Dinero total: ${fmt(u.coins + u.bank)}\n⌨️ Comandos usados: ${fmt(u.cmds)}`, [t]
      )
    },
  },
  {
    name: 'setbio', aliases: ['bio'], desc: 'Cambia la bio de tu perfil', usage: '<texto>',
    async run(c) {
      if (!c.text) return c.reply(`Uso: ${c.prefix}setbio <texto>`)
      c.user.bio = c.text.slice(0, 120)
      c.reply('✅ Bio actualizada.')
    },
  },
  {
    name: 'tienda', aliases: ['shop', 'store'], desc: 'Mira los artículos a la venta',
    async run(c) {
      c.reply('🛒 *Tienda*\n\n' + Object.entries(SHOP).map(([k, v]) => `› *${k}* — ${fmt(v.price)} 🪙\n   ${v.desc}`).join('\n') + `\n\nCompra con ${c.prefix}comprar <artículo>`)
    },
  },
  {
    name: 'comprar', aliases: ['buy'], desc: 'Compra un artículo de la tienda', usage: '<artículo>',
    async run(c) {
      const k = norm(c.args[0] || '')
      const item = SHOP[k]
      if (!item) return c.reply(`❌ Artículo no válido. Usa ${c.prefix}tienda`)
      if (k !== 'escudo' && c.user.inv[k]) return c.reply('Ya tienes ese artículo.')
      if (c.user.coins < item.price) return c.reply(`❌ Te faltan ${fmt(item.price - c.user.coins)} monedas.`)
      c.user.coins -= item.price
      c.user.inv[k] = (c.user.inv[k] || 0) + 1
      c.reply(`✅ Compraste *${k}* por ${fmt(item.price)} monedas.`)
    },
  },
  {
    name: 'inventario', aliases: ['inv', 'mochila'], desc: 'Mira tus objetos',
    async run(c) {
      const items = Object.entries(c.user.inv).filter(([, n]) => n > 0)
      c.reply('🎒 *Inventario*\n\n' + (items.map(([k, n]) => `› ${k}: ${n}`).join('\n') || 'Está vacío.'))
    },
  },
  {
    name: 'vender', aliases: ['sell'], desc: 'Vende gemas, peces o carne', usage: '<objeto> [cantidad|all]',
    async run(c) {
      const k = norm(c.args[0] || '')
      if (!SELL[k]) return c.reply(`Puedes vender: ${Object.entries(SELL).map(([n, p]) => `${n} (${p}🪙)`).join(', ')}\nUso: ${c.prefix}vender pez all`)
      const have = c.user.inv[k] || 0
      const n = amount(c, c.args[1] || '1', have)
      if (isNaN(n) || n < 1) return c.reply('❌ Cantidad inválida.')
      if (n > have) return c.reply(`❌ Solo tienes ${have} ${k}.`)
      c.user.inv[k] -= n
      c.user.coins += SELL[k] * n
      c.reply(`💵 Vendiste ${n} ${k} por *${fmt(SELL[k] * n)}* monedas.`)
    },
  },
]
