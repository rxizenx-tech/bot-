import * as F from '../lib/fonts.js'

export const category = 'Texto'

const input = (c) => c.text || c.quotedText || ''

// Fábrica: comando que transforma el texto recibido (o el mensaje citado)
const t = (name, aliases, desc, fn) => ({
  name, aliases, desc, usage: '<texto>',
  async run(c) {
    const s = input(c)
    if (!s) return c.reply(`Uso: ${c.prefix}${name} <texto>  (o responde a un mensaje)`)
    c.reply(fn(s))
  },
})

const LEET = { a: '4', e: '3', i: '1', o: '0', s: '5', t: '7', b: '8', g: '9' }

export default [
  t('negrita', ['bold'], 'Texto en negrita unicode', F.bold),
  t('cursiva', ['italic'], 'Texto en cursiva unicode', F.italic),
  t('mono', ['monoespacio'], 'Texto monoespaciado', F.mono),
  t('burbuja', ['bubble'], 'Letras en burbuja', F.bubble),
  t('versalitas', ['smallcaps'], 'Versalitas pequeñas', F.smallcaps),
  t('ancho', ['wide', 'vaporwave'], 'Texto ancho (fullwidth)', F.wide),
  t('voltear', ['flip', 'reves'], 'Voltea el texto de cabeza', F.flip),
  t('tachado', ['strike'], 'Texto tachado', F.strike),
  t('subrayado', ['underline'], 'Texto subrayado', F.underline),
  t('zalgo', ['glitch'], 'Texto glitch / zalgo', F.zalgo),
  t('mayus', ['upper', 'mayusculas'], 'Todo en MAYÚSCULAS', (s) => s.toUpperCase()),
  t('minus', ['lower', 'minusculas'], 'todo en minúsculas', (s) => s.toLowerCase()),
  t('capitalizar', ['capitalize', 'titulo'], 'Primera Letra De Cada Palabra', (s) =>
    s.toLowerCase().replace(/(^|\s)\S/g, (m) => m.toUpperCase())),
  t('invertir', ['reverse'], 'Invierte el orden de las letras', (s) => [...s].reverse().join('')),
  {
    name: 'repetir', aliases: ['repeat'], desc: 'Repite un texto N veces (máx 30)', usage: '<veces> <texto>',
    async run(c) {
      const n = Math.min(parseInt(c.args[0]), 30)
      const s = c.args.slice(1).join(' ') || c.quotedText
      if (isNaN(n) || n < 1 || !s) return c.reply(`Uso: ${c.prefix}repetir 3 hola`)
      c.reply(Array(n).fill(s).join(' '))
    },
  },
  {
    name: 'contar', aliases: ['count', 'caracteres'], desc: 'Cuenta letras, palabras y líneas', usage: '<texto>',
    async run(c) {
      const s = input(c)
      if (!s) return c.reply(`Uso: ${c.prefix}contar <texto>`)
      const words = s.trim().split(/\s+/).filter(Boolean).length
      const vowels = (s.normalize('NFD').match(/[aeiou]/gi) || []).length
      c.reply(`🔤 *Conteo*\n\nCaracteres: ${[...s].length}\nSin espacios: ${s.replace(/\s/g, '').length}\nPalabras: ${words}\nLíneas: ${s.split('\n').length}\nVocales: ${vowels}`)
    },
  },
  t('leet', ['1337'], 'Escribe en lenguaje hacker (leet)', (s) =>
    [...s].map((ch) => LEET[ch.toLowerCase()] || ch).join('')),
  t('mock', ['burla'], 'eStE TeXtO aLtErNaDo', (s) =>
    [...s.toLowerCase()].map((ch, i) => (i % 2 ? ch.toUpperCase() : ch)).join('')),
  t('aplauso', ['clap'], 'Pon 👏 entre 👏 las 👏 palabras', (s) => s.trim().split(/\s+/).join(' 👏 ') + ' 👏'),
  t('palindromo', ['palindrome'], 'Dice si un texto es palíndromo', (s) => {
    const clean = s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]/g, '')
    if (!clean) return '❌ Escribe letras o números.'
    return clean === [...clean].reverse().join('')
      ? `✅ "${s}" *sí* es un palíndromo.`
      : `❌ "${s}" *no* es un palíndromo.`
  }),
]
