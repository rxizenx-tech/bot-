import config from '../config.js'

export const category = 'Media'

export default [
  {
    name: 'sticker', aliases: ['s', 'stiker'], desc: 'Crea un sticker de una imagen o video corto', usage: '(imagen o respondiendo a una)',
    async run(c) {
      const media = await c.getMedia()
      if (!media) return c.reply(`Envía una imagen/video con el comando ${c.prefix}sticker, o respóndeme a uno.`)
      const { Sticker, StickerTypes } = await import('wa-sticker-formatter')
      const sticker = new Sticker(media.buffer, {
        pack: config.stickerPack,
        author: config.stickerAuthor,
        type: StickerTypes.FULL,
        quality: 60,
      })
      await c.send({ sticker: await sticker.toBuffer() })
    },
  },
  {
    name: 'toimg', aliases: ['img', 'aimagen'], desc: 'Convierte un sticker (estático) en imagen', usage: '(respondiendo a un sticker)',
    async run(c) {
      const media = await c.getMedia()
      if (!media || media.type !== 'stickerMessage') return c.reply('Responde a un *sticker* con este comando.')
      const sharp = (await import('sharp')).default
      const png = await sharp(media.buffer).png().toBuffer()
      await c.send({ image: png, caption: '✅ Listo' })
    },
  },
]
