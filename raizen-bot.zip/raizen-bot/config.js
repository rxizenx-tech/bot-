// ============================================================
//  CONFIGURACIÓN DEL BOT  (edita solo este archivo)
// ============================================================
export default {
  botName: 'RAIZEN BOT',

  // Prefijos que activan comandos. Se pueden cambiar en vivo con .setprefix
  prefix: ['.', '!', '/', '#'],

  // Números dueños (solo dígitos, con código de país, SIN el +).
  // Ejemplo Costa Rica: '50688888888'
  owners: ['50688888888'],

  // Si pones tu número aquí, el bot te dará un CÓDIGO DE EMPAREJAMIENTO
  // en vez de un QR. Déjalo vacío ('') para usar QR.
  pairingNumber: '',

  // 'public' = todos usan el bot | 'private' = solo los dueños
  mode: 'public',

  // Zona horaria por defecto para .fecha y .hora
  timezone: 'America/Costa_Rica',

  // Carpeta donde se guarda la sesión de WhatsApp
  sessionDir: 'session',

  // Textos
  repo: 'https://github.com/TU_USUARIO/raizen-bot',
  donate: '💖 Gracias por querer apoyar el proyecto. Contacta al creador para donar.',
  stickerPack: 'RAIZEN BOT',
  stickerAuthor: 'raizen',

  // Segundos de espera entre comandos por usuario (anti-spam)
  cooldown: 1.5,
}
