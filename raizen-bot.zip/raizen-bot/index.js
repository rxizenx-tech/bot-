// Lanzador: ejecuta main.js y lo reinicia solo si se cae o si usas .restart
import { fork } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

const file = path.join(path.dirname(fileURLToPath(import.meta.url)), 'main.js')
let child = null
let stopping = false

function run() {
  child = fork(file, { stdio: 'inherit' })
  child.on('exit', (code) => {
    if (stopping || code === 100) process.exit(0) // 100 = parada intencional
    console.log(`🔄 Reiniciando el bot (código ${code})...`)
    setTimeout(run, 2000)
  })
}

const stop = () => {
  stopping = true
  child?.kill('SIGTERM')
  setTimeout(() => process.exit(0), 1500)
}
process.on('SIGINT', stop)
process.on('SIGTERM', stop)

run()
