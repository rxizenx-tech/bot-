import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  Browsers,
} from '@whiskeysockets/baileys'
import pino from 'pino'
import qrcode from 'qrcode-terminal'
import config from './config.js'
import db from './lib/db.js'
import { loadCommands } from './lib/loader.js'
import { handleMessage, handleParticipants } from './lib/handler.js'

const logger = pino({ level: 'silent' })

const total = await loadCommands()
console.log(`📦 ${total} comandos cargados`)

async function start() {
  const { state, saveCreds } = await useMultiFileAuthState(config.sessionDir)
  const { version } = await fetchLatestBaileysVersion()

  const sock = makeWASocket({
    version,
    logger,
    auth: { creds: state.creds, keys: makeCacheableSignalKeyStore(state.keys, logger) },
    browser: Browsers.ubuntu('Chrome'),
    markOnlineOnConnect: false,
    syncFullHistory: false,
    getMessage: async () => undefined,
  })

  // Código de emparejamiento (si configuraste pairingNumber)
  if (!sock.authState.creds.registered && config.pairingNumber) {
    setTimeout(async () => {
      try {
        const code = await sock.requestPairingCode(config.pairingNumber.replace(/\D/g, ''))
        console.log(`\n🔑 Código de emparejamiento: ${code.match(/.{1,4}/g).join('-')}`)
        console.log('   WhatsApp > Dispositivos vinculados > Vincular con el número de teléfono\n')
      } catch (e) {
        console.error('No se pudo generar el código:', e.message)
      }
    }, 3000)
  }

  sock.ev.on('creds.update', saveCreds)

  sock.ev.on('connection.update', ({ connection, lastDisconnect, qr }) => {
    if (qr && !config.pairingNumber) {
      console.log('\n📱 Escanea este QR con WhatsApp > Dispositivos vinculados:\n')
      qrcode.generate(qr, { small: true })
    }
    if (connection === 'open') console.log(`✅ ${config.botName} conectado como ${sock.user.id}`)
    if (connection === 'close') {
      const code = lastDisconnect?.error?.output?.statusCode
      if (code === DisconnectReason.loggedOut) {
        console.log('❌ Sesión cerrada. Borra la carpeta "session" y vuelve a vincular.')
        process.exit(100)
      }
      console.log(`⚠️ Conexión cerrada (${code ?? '?'}), reconectando...`)
      setTimeout(start, 2000)
    }
  })

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return
    for (const m of messages) {
      try {
        await handleMessage(sock, m)
      } catch (e) {
        console.error('Error procesando mensaje:', e)
      }
    }
  })

  sock.ev.on('group-participants.update', (ev) => handleParticipants(sock, ev).catch(console.error))
}

const shutdown = () => {
  db.save()
  process.exit(100)
}
process.on('SIGINT', shutdown)
process.on('SIGTERM', shutdown)
process.on('unhandledRejection', (e) => console.error('unhandledRejection:', e))
process.on('uncaughtException', (e) => console.error('uncaughtException:', e))

start()
